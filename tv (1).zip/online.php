<HTML>
####IPTV M3U Written by  Admin PLAYIDTV
Thank you for liking it. Admin, if you want to develop, you must continue to develop.  ####


#https://dm0qx8t0i9gc9.cloudfront.net/watermarks/video/BQdq7_9MOklqngtkv/videoblocks-61dc77e29afa4f098010ed94_rwzecn-ak__7cb6c27a74e0204cc321dc71b4a076b0__P360.mp4



####IPTV M3U Written by  Admin PLAYIDTV
#EXTM3U
 url-tvg="https://www.bevy.be/bevyfiles/thailand.xml, https://playidturl1.github.io/epgtv/gigatv.xml, https://playidturl1.github.io/epgtv/thailand.xml, "refresh="3600"
"url="",

#EXTINF:-1 " tvg-name="" tvg-logo="https://cdn-icons-png.flaticon.com/512/5359/5359971.png" group-title="ข้อมูล", 19/12/23(19:00)
https://heylink.me/playidtv/


#EXTINF:-1 group-title="ดูบอลสด" tvg-id="" tvg-logo="https://rentapi.blackboxsys.net/images/png/hd-tsport2.png",01:00 - อุราวะ เร้ดส์ ไดมอนด์ส vs แมนเชสเตอร์ ซิตี้
https://dolive.thaim3u.com/tFQe38qxw4awKkMJD3kcfcekVSrfLnY9/siamsport-9/playlist.m3u8|Referer=https://ufabetcompany.app


#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM1.png",ช่องสด 
https://2nud.short.gy/LIVE1
https://2nud.short.gy/LIVE2
https://2nud.short.gy/LIVE3



#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM2.png", SPORTS LIVE 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd1/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM2.png", SPORTS LIVE 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd2/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM3.png", SPORTS LIVE 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd3/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM1.png", SPORTS LIVE 4
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd4/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM5.png", SPORTS LIVE 5
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd5/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/BM6.png", SPORTS LIVE 6
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd6/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/ch77.png", SPORTS LIVE 7
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd7/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/ch88.png", SPORTS LIVE 8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/sd8/playlist.m3u8
#EXTINF:-1 group-title="LIVESOD" tvg-id="" tvg-logo="https://ballmun.com/asset/icon/ch99.png", SPORTS LIVE 9
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ballmun.com
https://cdn.dooball66.xyz/ballmun_live/bein1/playlist.m3u8

#EXTINF:-1 tvg-chno="2" tvg-id="NBT2.th" tvg-name="NBT HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0001.png" group-title="TV DIGITAL", NBT
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0001/HLS/V0001.m3u8



#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=ca20a93cf8e3421dafbd5bdb1990081b:86ae86a7391c481ea93eecdb740f0a14
#https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/2/2.mpd


#EXTINF:-1 tvg-chno="3" tvg-id="ThaiPBS3.th" tvg-name="THAI PBS HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0014.png" group-title="TV DIGITAL",  THAI PBS HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0014/HLS/V0014-avc1_5000000=2-mp4a_64000_tha=6.m3u8
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=4d4426a505f64382a9841155d721cee6:0f4770219ccb4be5836a7517057e51c3
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/3/3.mpd
#EXTINF:-1 tvg-chno="4" tvg-id="ALTV.th" tvg-name="ALTV" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/ALTV.PNG" group-title="TV DIGITAL",  ALTV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/ALTV/index.m3u8
#EXTINF:-1 tvg-chno="5" tvg-id="TV5HD.th" tvg-name="TV5 HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon//ch5new.logo.png" group-title="TV DIGITAL", TV5 HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0007/HLS/V0007-avc1_5000000=3-mp4a_64000_tha=7.m3u8
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=87db4361f7894655a4656e9c8b935a02:b025a4b950df41158a87cfc8d6f2ac34
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/5/5.mpd
#EXTINF:-1 tvg-chno="7" tvg-id="TSports7.th" tvg-name="T Sports 7" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/T-SPorts_7_Final.png" group-title="TV DIGITAL",TSports7
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=6187523f92b9475bb5b192f70cef1342:5119311f482144d58dacabc5bc1fa4ba
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/7/7.mpd
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chtsport/index.m3u8
#EXTINF:-1 tvg-chno="10" tvg-id="TPTV.th" tvg-name="TPTV" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0048.png" group-title="TV DIGITAL",  TPTV 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/TPTV/index.m3u8
#EXTINF:-1 tvg-id="TNN2.th" tvg-name="TNN 2" tvg-logo="https://cms.dmpcdn.com/livetv/2017/10/18/f1b957db-b175-45fc-ab2b-60150f9c570a.png" group-title="TV DIGITAL",TNN 2
https://ctrl.laotv.la/live/TNN2/index.m3u8
#EXTINF:-1 tvg-chno="16" tvg-id="TNN16.th" tvg-name="TNN 16" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R2_0053.png" group-title="TV DIGITAL", TNN 16 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0053/HLS/V0053-avc1_2000000=4-mp4a_64000_tha=2.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chtnn/index.m3u8
#EXTINF:-1 tvg-chno="18" tvg-id="JKN18.th" tvg-name="JKN 18" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/JKN18.png" group-title="TV DIGITAL", JKN18TopNews 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/newtv/index.m3u8
#EXTINF:-1 tvg-chno="22" tvg-id="NationTV.th" tvg-name="Nation TV" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0021.png" group-title="TV DIGITAL", Nation TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chnation/index.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://ctrl.laotv.la/live/NationTV/index.m3u8
#EXTINF:-1 tvg-chno="23" tvg-id="Workpoint23.th" tvg-name="Workpoint" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0015_R.png" group-title="TV DIGITAL", WorkpointTV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chworkpoint/index.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://ctrl.laotv.la/live/WorkPoint/index.m3u8
#EXTINF:-1 tvg-chno="24" tvg-id="True4U.th" tvg-name="True 4U" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0054.png" group-title="TV DIGITAL", True4U
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chtrue4u3/index.m3u8
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=4eabd5db684248a98c5124fbb0687bde:d2f7a6f45b3c48678ca69c91d7823c25
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/24/24.mpd
#EXTINF:-1 tvg-chno="25" tvg-id="GMM25.th" tvg-name="GMM 25" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0019.png" group-title="TV DIGITAL", GMM25
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://2nud.short.gy/ais_gmm25.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chgmm/index.m3u8
#EXTINF:-1 tvg-chno="28" tvg-id="ThaiChannel8.th" tvg-name="CH8" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0006.png" group-title="TV DIGITAL",  CH8
#https://ctrl.laotv.la/live/CH8/index.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/ch8/index.m3u8
#EXTINF:-1 tvg-chno="29" tvg-id="Mono29.th" tvg-name="MONO 29" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0016.png" group-title="TV DIGITAL", MONO 29 TH
https://edge4-bkk.3bb.co.th:9443/Stream_HLSMONO29_1080P/mono29hls_1080TH.stream/playlist.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://edge6a.v2h-cdn.com/mono/mono.stream/playlist.m3u8
EXTINF:-1 tvg-chno="29" tvg-id="Mono29.th" tvg-name="MONO 29" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0016.png" group-title="TV DIGITAL", [CH29] MONO 29 EN
#https://edge4-bkk.3bb.co.th:9443/Stream_HLSMONO29_1080P/mono29hls_1080EN.stream/playlist.m3u8
#EXTINF:-1 tvg-chno="30" tvg-id="MCOTHD.th" tvg-name="MCOT HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/MCOT_new.png" group-title="TV DIGITAL",   MCOT HD
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0008/HLS/V0008.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chmcothd3/index.m3u8
#EXTINF:-1 tvg-chno="31" tvg-id="OneHD.th" tvg-name="ONE HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0012.png" group-title="TV DIGITAL",  ONEHD 31
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/B0012/HLS/B0012.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chonehd/index.m3u8
#EXTINF:-1 tvg-chno="32" tvg-id="ThairathTV.th" tvg-name="Thairath TV" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0013_R.png" group-title="TV DIGITAL", Thairath TV
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0013/HLS/V0013.m3u8
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0013/HLS/V0013-avc1_5000000=7-mp4a_64000_tha=2.m3u8
#EXTINF:-1 tvg-chno="33" tvg-id="CH3.th" tvg-name="CH3 HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/LOGO3HD.PNG" group-title="TV DIGITAL",  CH3HD
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/B0003/HLS/B0003-avc1_5000000=5-mp4a_64000_tha=6.m3u8
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/B0003/DASH/B0003.mpd
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/ch3hd/index.m3u8
#EXTINF:-1 tvg-chno="34" tvg-id="Amarin34HD.th" tvg-name="Amarin TV" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/AmarinTV_NEW512.png" group-title="TV DIGITAL",AMARINTV
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0017/HLS/V0017-avc1_5000000=14-mp4a_64000_tha=9.m3u8
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0017/DASH/V0017.mpd
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chamarin/index.m3u8
#EXTINF:-1 tvg-chno="35" tvg-id="BBTVChannel7.th" tvg-name="CH7 HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0018.png" group-title="TV DIGITAL",  BBTV Channel 7
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0018/HLS/V0018-avc1_5000000=7-mp4a_64000_tha=2.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/ch7hd/index.m3u8
https://live-cdn-hwc.ch7.com/livech7hd/HD_1080p.m3u8?vhost=streaming-hwc.ch7.com
#EXTINF:-1 tvg-chno="36" tvg-id="PPTVHD36.th" tvg-name="PPTV HD" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R_0022.png" group-title="TV DIGITAL", PPTV HD
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0022/HLS/V0022-avc1_5000000=7-mp4a_64000_tha=2.m3u8
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=0aeffa7753674e77b99443fac7757b8a:b8c8a462008a40aa91823e0b02e8dd31
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/36/36.mpd



#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/VTVNews.png" group-title="News",VTVNews
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://49-231-37-229-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0026/HLS/V0026.m3u8
#EXTINF:-1 tvg-id="thaichaiyo.tv" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRx654fX_dwPSG96lmrCaevzeELFdRJZZ8BLQ&usqp=CAU" group-title="หนังภาพยนตร์",ไทไชโย
https://live-iptv.thaichaiyo.tv/tcy/live-720P.m3u8
#EXTINF:-1 tvg-id="FiveChannel.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0096.png" group-title="เอไอเอส เพลย์ ",FIVE CHANNEL
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0096/HLS/V0096.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R_0059.png" group-title="เอไอเอส เพลย์ ", White Channel
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://49-231-37-229-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0059/HLS/V0059.m3u8
#EXTINF:-1 tvg-id="Newtm" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/NEW_TM.png" group-title="เอไอเอส เพลย์ ", NEW TM
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://vdo.plathong.net/flash7253/flash7253/playlist.m3u8
#EXTINF:-1 tvg-id="CoolChannel.th" tvg-name="Cool Channel" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/18/7c07f020-2515-11ee-ac34-39c66cab230f_webp_original.webp" group-title="หนังภาพยนตร์ ",Cool Channel
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://live-iptv.cool-channel.com/cool/live-720P.m3u8


#EXTINF:-1 tvg-id="KhongDeeThailand.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///KhongDeeThailand.png" group-title="เอไอเอส เพลย์ ",KhongDeeThailand
https://49-231-37-237-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0154/HLS/V0154.m3u8
#EXTINF:-1 tvg-id="Thainess.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///Thainess.png" group-title="เอไอเอส เพลย์ ",Thainess
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0155/HLS/V0155.m3u8
#EXTINF:-1 tvg-id="SamRujLok.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///SamRujLok.png" group-title="เอไอเอส เพลย์ ",SamRujLok
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0151/HLS/V0151.m3u8
#EXTINF:-1 tvg-id="MySCI.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///MySCI.png" group-title="เอไอเอส เพลย์ ",MySCI
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0152/HLS/V0152.m3u8
#EXTINF:-1 tvg-id="KhongDeeThailand.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///AnimalShow.png" group-title="เอไอเอส เพลย์ ",AnimalShow
https://49-231-37-237-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0153/HLS/V0153.m3u8
EXTINF:-1 tvg-id="Thainess.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///Thainess.png" group-title="เอไอเอส เพลย์ ",Thainess
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0155/HLS/V0155.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/V0112.png" group-title="เอไอเอส เพลย์ ", TrueSelect 
https://49-231-37-229-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0111/HLS/V0112.m3u8

#EXTINF:-1 tvg-chno="37" tvg-id="" tvg-name="" tvg-logo="https://yateem.tv/wp-content/uploads/2019/01/Logo-Header.png" group-title="TV DIGITAL",YATEEM TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://vdo.plathong.net/wowza/muslimonair1/live/playlist.m3u8
EXTINF:-1 tvg-chno="38" tvg-id="RamaChannel.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R_0059.png" group-title="TV DIGITAL",TVMUSLIM
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#http://vip2.liveanywhere.asia:1935/tvmuslim/tvmuslim/playlist.m3u8
#EXTINF:-1 tvg-id="High Shopping" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R_0111.png" group-title="เอไอเอส เพลย์ ",High Shopping
https://49-231-37-229-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0052/HLS/V0052.m3u8
#EXTINF:-1 tvg-id="True Shopping" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/R_0111.png" group-title="เอไอเอส เพลย์ ",True Shopping
https://49-231-37-229-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0111/HLS/V0111.m3u8


#EXTINF:-0 group-title="AIS SPORTS" tvg-logo="https://blingtv.net/channels/images/BALLTHAI_1.png", 3BB-BALLTHAI 1
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=OTFmNDAwZWEtZjI5OC0zNTAzLWE0NzktZWI2NGIxMjRmMGFm
https://cnt1-streamer5.cdn.3bbtv.com:8443/3bb/tstv/901/901.mpd
#EXTINF:-0 group-title="AIS SPORTS" tvg-logo="https://blingtv.net/channels/images/BALLTHAI_2.png", 3BB-BALLTHAI 2
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=OTFmNDAwZWEtZjI5OC0zNTAzLWE0NzktZWI2NGIxMjRmMGFm
https://cnt1-streamer7.cdn.3bbtv.com:8443/3bb/tstv/902/902.mpd
#EXTINF:-0 group-title="AIS SPORTS" tvg-logo="https://blingtv.net/channels/images/BALLTHAI_3.png", 3BB-BALLTHAI 3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=OTFmNDAwZWEtZjI5OC0zNTAzLWE0NzktZWI2NGIxMjRmMGFm
https://cnt1-streamer1.cdn.3bbtv.com:8443/3bb/tstv/903/903.mpd

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//BALLTHAI_1.png", group-title="AIS SPORTS", BALLTHAI 1
#EXTVLCOPT:http-referrer=https://ais-vidnt.com
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/TL001/HLS/TL001.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//BALLTHAI_2.png", group-title="AIS SPORTS", BALLTHAI 2
#EXTVLCOPT:http-referrer=https://ais-vidnt.com
https://49-231-37-236-rewriter.ais-vidnt.com/ais/play/origin/live/eds/TL002/HLS/TL002.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//BALLTHAI_3.png", group-title="AIS SPORTS", BALLTHAI 3
#EXTVLCOPT:http-referrer=https://ais-vidnt.com
https://49-231-34-108-rewriter.ais-vidnt.com/ais/play/origin/live/eds/TL003/HLS/TL003.m3u8
#EXTINF:-1 tvg-name="AIS PLAY SPORTS 1" tvg-id="AIS PLAY SPORTS 1" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon///AISPLAY_SPORTS1.png" group-title="AIS SPORTS", AIS PLAY SPORTS 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/TL101/DASH/TL101.mpd





#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truepremierfootball1.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/03/ba425a00-e966-11ed-be07-cbff4c6d2c94_webp_original.webp",True PremierHD 1
https://wacthstream.com/stream_live/600_eng1/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA1OjM2OjQ0IFBNJmhhc2hfdmFsdWU9OVNIUlJPczdMaVFiazZNWXRDTDRiQT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzU2MDAz|Referer=https://wacth.tv
#EXTVLCOPT:http-user-agent=ExoPlayerDemo/2.14 (Linux;Android 10) ExoPlayerLib/2.14.1
https://ctrl.laotv.la/live/TSport1/index.m3u8
#EXTVLCOPT:http-referrer=https://freetvdd.com
#EXTVLCOPT:http-user-agent=PotPlayer/1.7.20977 (Windows NT 10.0; Win64; x64)
https://streaming.livescorethai.net/iptv/epl-1.stream/playlist.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://raw.githubusercontent.com/Playidturl1/epgtv/main/ch/PremierHD1_chunklist.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truepremierfootball2.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/03/ba4c4510-e966-11ed-896e-69ce273284a6_webp_original.webp",True PremierHD 2 
#EXTVLCOPT:http-user-agent=PotPlayer/1.7.20977 (Windows NT 10.0; Win64; x64)
http://ip168.homeip.net:8086/2.m3u8

#EXTVLCOPT:http-referrer=https://freetvdd.com
#EXTVLCOPT:http-user-agent=ExoPlayerDemo/2.14 (Linux;Android 10) ExoPlayerLib/2.14.1
https://streaming.livescorethai.net/iptv/epl-2.stream/playlist.m3u8
https://ctrl.laotv.la/live/TSport2/index.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://raw.githubusercontent.com/Playidturl1/epgtv/main/ch/PremierHD2_chunklist.m3u8


#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truepremierfootball3.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/03/baf9ea30-e966-11ed-a3d3-f3f98ac7a1a1_webp_original.webp",True PremierHD 3
#EXTVLCOPT:http-referrer=https://freetvdd.com
#EXTVLCOPT:http-user-agent=ExoPlayerDemo/2.14 (Linux;Android 10) ExoPlayerLib/2.14.1
https://streaming.livescorethai.net/iptv/epl-3.stream/playlist.m3u8
https://iptv-th.com:443/play/cgi3Vu4KHTlfKImhvoBfMDSSwjL9QkWeG_ziGqHFYSg/.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://playidturl1.github.io/epgtv/ch/PremierHD3_chunklist.m3u8
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/epl-3.stream/playlist.m3u8
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truepremierfootball4.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/03/bb0beb90-e966-11ed-993c-b59183950f79_webp_original.webp",True PremierHD 4
#EXTVLCOPT:http-referrer=https://freetvdd.com
#EXTVLCOPT:http-user-agent=ExoPlayerDemo/2.14 (Linux;Android 10) ExoPlayerLib/2.14.1
https://streaming.livescorethai.net/iptv/epl-4.stream/playlist.m3u8
https://iptv-th.com:443/play/cgi3Vu4KHTlfKImhvoBfMOzHg9Y6IRIB6DGajUQFybk/.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://playidturl1.github.io/epgtv/ch/PremierHD4_chunklist.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truepremierfootball5.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/03/bbea1690-e966-11ed-935b-df134f58d288_webp_original.webp",True PremierHD 5
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://raw.githubusercontent.com/Playidturl1/epgtv/main/ch/PremierHD5_chunklist.m3u8
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/epl-5.stream/playlist.m3u8
https://iptv-th.com:443/play/cgi3Vu4KHTlfKImhvoBfMDnjzF2DZmAiEaOrY9Jo6Ps/.m3u8



#EXTINF:-1 group-title="TRUE VISION NOW " tvg-logo="https://cms.dmpcdn.com/livetv/2023/09/25/c3898e20-5b4f-11ee-a599-1d1a4f7c1125_webp_original.webp",TrueID LIVE
#KODIPROP:inputstream.adaptive.license_type=clearkey  #KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/truesport.html
https://cdn102.stm.trueid.net/p101daidrm/he003_multi_w_auto_wv_tidapp.smil/manifest_w1801095343_qYXBwaWQ9dHJ1ZWlkJnR5cGU9bGl2ZSZ2aXNpdG9yPXdlYiZkcm09d3YzJnVpZD0xNDA3MzIxMDUmZGlkPVYybFBTWEZmY0VsbVJIUnNaM2RvZFdsR01UaEVObVpVTFhkU2RYRmZhbXMmc2lkPTY1Zjc1NDEwNzcmcnQ9MTcwMjk4ODQxOCZkcz04NjQwMCZ0az14d2NEUEEyTlMyUnotVTBYSGxaWDllNkxMckEwZ0NSc25fLTlHN0NEM0Uw.mpd

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-logo="https://cms.dmpcdn.com/livetv/2023/09/25/c3898e20-5b4f-11ee-a599-1d1a4f7c1125_webp_original.webp",TrueID Sports 2
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=af23d7935f1b5f029cccbf7f45543813:142bc597c797bd6d0dc757ca73cfd16b
https://cdn132.stm.trueid.net/p101drm/he004_multi_w_auto_wv_tidapp.smil/manifest_w1424660976_qYXBwaWQ9dHJ1ZWlkJnR5cGU9bGl2ZSZ2aXNpdG9yPXdlYiZkcm09d3YzJnVpZD0xNDA3MzIxMDUmZGlkPVYybFBTWEZmY0VsbVJIUnNaM2RvZFdsR01UaEVObVpVTFhkU2RYRmZhbXMmc2lkPWJlYzY1ZWMyMzUmcnQ9MTcwMjk4ODQwNCZkcz04NjQwMCZ0az1VZ0JlNWNjLXZTN1JwUFZ6SnNzWVl0Ti0zUzdmeTBscHAyNEs5V0JWcm9B.mpd

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-logo="https://cms.dmpcdn.com/livetv/2023/09/25/c389b530-5b4f-11ee-a6f1-ffa978a40b9f_webp_original.webp",TrueID Sports 3
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=e0da90e772c45088bcfb74ab6fd11ce1:9afa9b813c3fb862d43a2117b480bd7a
https://cdn732.stm.trueid.net/p201drm/he005_multi_w_auto_wv_tidapp.smil/manifest_w1657755819_qYXBwaWQ9dHJ1ZWlkJnR5cGU9bGl2ZSZ2aXNpdG9yPXdlYiZkcm09d3YzJnVpZD0xNDA3MzIxMDUmZGlkPVYybFBTWEZmY0VsbVJIUnNaM2RvZFdsR01UaEVObVpVTFhkU2RYRmZhbXMmc2lkPWEyMjgzNTM4YjYmcnQ9MTcwMjk4ODM4NSZkcz04NjQwMCZ0az1Ra0tKWHBhVWEtOTNJNzlMbXNmQmdBYW0zMklVOUEtMnBJeEZmSTI4T0xv.mpd


#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truesports1.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/24/81825540-e28a-11ed-9bb2-7fe2e28bfd8c_webp_original.webp",True Sports 1
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-tsport1.stream/playlist.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
https://sport.livedoomovies.com:4432/02_2sporthd1_720p/chunklist.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truesports2.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/2960b3f0-e593-11ed-b26c-6b89d082d464_webp_original.webp",True Sports 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-tsport2.stream/playlist.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
https://sport.livedoomovies.com:4432/02_2sporthd2_720p/chunklist.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truesports3.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/296e96a0-e593-11ed-8507-4fc0b025fedb_webp_original.webp",True Sports 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
https://sport.livedoomovies.com:4432/02_2sporthd3_720p/chunklist.m3u8
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-tsport3.stream/playlist.m3u8
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truesports4.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/f4888970-e595-11ed-8507-4fc0b025fedb_webp_original.png",True Sports 4 
#EXTVLCOPT:http-referrer=https://freetvdd.com
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://streaming.livescorethai.net/iptv/hd-tsport4.stream/playlist.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="truesports5.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/f493fb20-e595-11ed-b26c-6b89d082d464_webp_original.webp",True Sports 5
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/sd-tsport5.stream/playlist.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
https://sport.livedoomovies.com:4432/02_sport5_480p/chunklist.m3u8
#EXTINF:-0 tvg-id="TrueSport7.th" tvg-name="TrueSport7" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/f63723d0-e595-11ed-abcb-c792e696f885_webp_original.webp" group-title="TRUE VISION NOW ",True Sports 7
https://streaming.livescorethai.net/iptv/sd-tsport7.stream/playlist.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
https://sport.livedoomovies.com:4432/02_sport7_480p/chunklist.m3u8
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/6057ad50-29cc-11ee-846b-a1c4e5181c87_webp_original.webp", Golf Channel
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://streaming.livescorethai.net/iptv/hd-golf.stream/playlist.m3u8|referer=https://streaming.livescorethai.net
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/6057ad50-29cc-11ee-846b-a1c4e5181c87_webp_original.webp", Golf Channel Thailand 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0130/DASH/V0130.mpd
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2021/10/25/9bc0de00-3565-11ec-a098-9b134fb8338e_webp_320.png", Golf Channel
http://ip168.homeip.net:8086/10.m3u8

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="spotv.kr" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/60cba4d0-29cc-11ee-b2f4-e9de482d866e_webp_320.webp",SPOTV 1 THAILAND
https://rr3-ic3d-ndjcs.huaweicdncloud.com/dooball2you/spotv1/playlist.m3u8?|Referer=https://dooball2you.com/

#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="spotv2.kr" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/61050450-29cc-11ee-b2f4-e9de482d866e_webp_320.webp",SPOTV 2 THAILANDTV
https://rr3-ic3d-ndjcs.huaweicdncloud.com/dooball2you/spotv2/playlist.m3u8?|Referer=https://dooball2you.com/


#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="beinsports1thailand.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/5f3c5240-29cc-11ee-b2f4-e9de482d866e_webp_original.webp", Bein Sports 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://ctrl.laotv.la/live/Bsport1/index.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net/
https://streaming.livescorethai.net/iptv/epl-bein1.stream/playlist.m3u8
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#https://www.livedoomovies.com:4432/02_epl1_720p/chunklist.m3u8
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="beinsports2thailand.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/5f346300-29cc-11ee-b2f4-e9de482d866e_webp_original.webp", Bein Sports  2 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#https://ctrl.laotv.la/live/Bsport2/index.m3u8
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net/
https://streaming.livescorethai.net/iptv/epl-bein2.stream/playlist.m3u8
https://rr3-ic3d-ndjcs.huaweicdncloud.com/andaman888th/bein2/playlist.m3u8|referer=https://www.andaman888th.com/
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="beinsports3thailand.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/07/24/5fda18e0-29cc-11ee-846b-a1c4e5181c87_webp_original.webp", Bein Sports 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net/
https://streaming.livescorethai.net/iptv/epl-bein3.stream/playlist.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.doomovie-hd.com
#https://sport.livedoomovies.com:4432/02_epl2_720p/chunklist.m3u8


#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/f65ea900-e595-11ed-86b8-bb40638e3c49_webp_original.webp", TENNIS HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
https://streaming.livescorethai.net/iptv/hd-tennis.stream/playlist.m3u8|referer=https://freetvdd.com

https://www.livedoomovies.com:4432/02_TennisHD_720p/chunklist.m3u8|Referer=https://www.doomovie-hd.com
#EXTINF:-1 group-title="TRUE VISION NOW " tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/09/15/35349410-5363-11ee-8322-fb6a8c8f2ff6_webp_original.webp", Motorvision (TH)
https://wacthstream.com/stream_live/687_motorvision/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA1OjQ4OjIwIFBNJmhhc2hfdmFsdWU9cEd2NjJZcXhRTHdRRE5pY0M0SEs2dz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzMwNzcw|referer=https://wacth.tv/

###  AISPLAY Sports ####


#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="beIN SPORTS 1.th" tvg-logo="https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS1_DIGITAL_Mono.png", BEIN SPORTS 1
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports1.html
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/S0001/DASH/S0001.mpd

#EXTINF:-1 tvg-id="beIN SPORTS 2.th" tvg-name="" tvg-logo="https://ais-s.demo-vidnt.com/ais/play/origin/LIVE/channelicon/beIN_SPORTS_2.png" group-title="AISPLAY PREMIUM",BEIN SPORTS 2
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports2.html
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/S0002/DASH/S0002.mpd
#EXTINF:-1 tvg-id="beIN SPORTS 3.th" tvg-name="" tvg-logo="https://ais-s.demo-vidnt.com/ais/play/origin/LIVE/channelicon/beIN_SPORTS_3.png" group-title="AISPLAY PREMIUM", BEIN SPORTS 3
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports3.html
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/S0003/DASH/S0003.mpd

#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="beinsports4ar.id" tvg-logo="https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS4_DIGITAL_Mono.png", BEIN SPORTS 4
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports4.html
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/S0004/DASH/S0004.mpd

#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="beinsports5ar.id" tvg-logo="https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS5_DIGITAL_Mono.png", BEIN SPORTS 5
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports5.html
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/S0005/DASH/S0005.mpd

#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="beinsports6ar.id" tvg-logo="https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS6_DIGITAL_Mono.png", BEIN SPORTS 6
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/beinsports6.html
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/S0006/DASH/S0006.mpd

#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="beinsports7ar.id" tvg-logo="https://assets.bein.com/mena/sites/3/2015/06/beIN_SPORTS7_DIGITAL_Mono.png",BEIN SPORTS 7
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=hhttps://vercel-php-clearkey-hex-base64-json.vercel.app/api/results.php?keyid=94a28a75b3891e92a97efbe76f941095&key=7b39cd0e318ee481b98c36a125c540fb
https://49-2310-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/S0007/DASH/S0007.mpd


#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//EUROSPORT.png" group-title="AISPLAY PREMIUM", EUROSPORT
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/eurosport.html
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0184/DASH/V0184.mpd

#EXTINF:-1 tvg-id="3BBSportone.th" tvg-name="3BB Sport one" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//3BBsports1_new.png" group-title="AISPLAY PREMIUM",3BBSportOne
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/3bbsport.html
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0190/DASH/V0190.mpd

#EXTINF:-1 tvg-id="3BBSportone.th" tvg-name="3BB Sport one" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//3BBsports1_new.png" group-title="3BBTV", 3BBSportOne
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=678bbba596584ad895d2923fb0255e82:c55471086c824112b217743a31abdf8f
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/401/401.mpd


#EXTINF:-0 group-title="3BBTV" tvg-id="hbo.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/R_0148.png", HBO TH
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=9c5735afb4fd402580360aed8364469c:128d55d9ac2b47ad85f86b5d08320179
https://cnt1-streamer9.cdn.3bbtv.com:8443/3bb/live/103/103.mpd
#EXTINF:-0 group-title="AISPLAY PREMIUM" tvg-id="hbo.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/R_0148.png", HBOTH
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/hbo.html
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0114/DASH/V0114.mpd
#https://wacthstream.com/stream_live/3BB_HBO/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjE3OjIwIFBNJmhhc2hfdmFsdWU9NlJOY0U4UXF6V3M5ZmFrZ281eFpzUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzg0NDg5|Referer=https://wacth.tv

#EXTINF:-0 group-title="3BBTV" tvg-id="hbosignature.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0149.png", HBO Signature
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/hbosig.html
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/104/104.mpd

#EXTINF:-0 group-title="AISPLAY PREMIUM" tvg-id="hbosignature.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0149.png", HBO Signature
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=97c1c27765dae9b95ee04ea6e8f50c34:7db57b354d4d9cdb22e256c2a7500956
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0117/DASH/V0117.mpd


#EXTINF:-0 group-title="AISPLAY PREMIUM" tvg-id="HBOHits.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0151.png", HBO Hits
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=56c2717c2c6431c75ac1fbf64a997cb6:d4544ffd929b2da1f6101705e74facee
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0116/DASH/V0116.mpd

#EXTINF:-0 group-title="3BBTV" tvg-id="HBOHits.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//0151.png", HBO Hits
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=7c04b8e7aa524afea879b2ed1aef8242:91e72b75fcb94c3bb36cceb741afd621
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/105/105.mpd
#EXTINF:-0 group-title="3BBTV" tvg-id="HBOFamily.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0150.png",HBO FAMILY
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=07b138f30ad3441ca5a2f476e550af25:826ee4deef4b45cfafd5f79a591b15c6
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/106/106.mpd
#EXTINF:-0 group-title="AISPLAY PREMIUM" tvg-id="HBOFamily.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0150.png",HBO FAMILY
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=96af42ae402ccc9b3f92a8e99ec8f5aa:6a0991ae3f06f76a010afa5515f67ac6
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0115/DASH/V0115.mpd


#EXTINF:-1 group-title="3BBTV" tvg-id="cinemaxasia.sg" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0147.png",CINEMAX
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=f48caba466394e93b50780f21798787a:9a074a10db4342e7937076b3e52f6029
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/107/107.mpd
#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="cinemaxasia.sg" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0147.png",CINEMAX 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=b541612bcb4598f60c4efc1733b5d8c9:7e6d2819c0912a204fd5478f8a60d1b5
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0118/DASH/V0118.mpd
#https://wacthstream.com/stream_live/3BB_CINEMAX/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjE3OjU4IFBNJmhhc2hfdmFsdWU9L0k3ekZxU1JMbGhNMnkrWFBBRHc4UT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzM5MjM4|Referer=https://wacth.tv

#EXTINF:-1 tvg-id="3BBAsian.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//3BBAsian_new.png" group-title="AISPLAY PREMIUM", 3BB Asian
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=379c40f0207c33f804d115d3ba77ee63:b20b45bea3d8bc7ad4961f813e79d0c1
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0191/DASH/V0191.mpd






#EXTINF:-0 group-title="หนังภาพยนตร์" tvg-id="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0091.png", Major Channel
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0091/DASH/V0091.mpd
#EXTINF:-0 group-title="หนังภาพยนตร์" tvg-id="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0090.png", MVTV Family
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0090/DASH/V0090.mpd
#EXTINF:-0 group-title="หนังภาพยนตร์" tvg-id="" tvg-logo="http://www.channel8thailand.com/img/18378709_1492777084098686_554998105_o.png", Channel 8 THAILAND
https://cdn-th-vip.livestreaming.in.th/ch8/ch8/playlist.m3u8
#EXTINF:-1 tvg-id="WarnerTV" tvg-name="TH - WARNER" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0105.png" group-title="AISPLAY PREMIUM", Warner TV
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=00a6eeb6a8623e7f5dd0de890fc55f52:57349ce17aa9f5692ad2fb7d9cdb01c7
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/X105/DASH/X105.mpd

#https://streaming.livescorethai.net/iptv/hd-warnertv.stream/playlist.m3u8?|Referer=https://freetvdd.com
#EXTINF:-1 tvg-id="Hits.sg" tvg-name="Hits" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//HITS.png" group-title="AISPLAY PREMIUM", Hits
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=947a5fdf30b55968f25dce4e80074e4d:ec10530ba2e6861bdb6b18881aadff46
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0137/DASH/V0137.mpd
#EXTINF:-0 tvg-id="HITS.Movies.HD.my" tvg-name="HITS Movies" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//HitsMovie.png" group-title="AISPLAY PREMIUM",HITS Movies
#http://playtv.my.id/play/hitsmovie.m3u8
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=addb5987eda9963ed765295d835b8cc5:7a2df5920917f98f667aed830c92f084
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0138/DASH/V0138.mpd


#EXTINF:-0 tvg-id="AXNThailand.th" tvg-name="AXN" tvg-logo="https://cms.dmpcdn.com/livetv/2019/01/24/a1e34189-e612-4afa-b784-6a01215bc592.png" group-title="หนังภาพยนตร์",TH AXN
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-axn.stream/playlist.m3u8
#EXTINF:-0 tvg-id="" tvg-name="" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSWjQ-5nl_D6X1OgtYzuA_pU9xVVCDV0ivSQ&usqp=CAU" group-title="หนังภาพยนตร์", NK Movie
http://sv1.afdc.live:9898/live/nktv.stream/playlist.m3u8
#EXTINF:-1 group-title="หนังภาพยนตร์" tvg-id="CCM" tvg-logo="https://cms.dmpcdn.com/livetv/2018/12/17/febce46e-fb05-41d9-b294-08ecb3f1d1e6.png",CCM
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/sd-celestial.stream/playlist.m3u8
#https://wacthstream.com/stream_live/233_CCM/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvNi8yMDIzIDExOjEzOjQ4IEFNJmhhc2hfdmFsdWU9S2tsWUdhem9WcGlIWTFtbUp6QTRiUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzIwMjgx|Referer=https://wacth.tv
#EXTINF:0 tvg-id="" tvg-logo="https://cms.dmpcdn.com/livetv/2022/06/01/bcfd3840-e18e-11ec-9395-ffdbbc2b7b61_webp_original.png" group-title="หนังภาพยนตร์", TVB XING
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/sd-tvb.stream/chunks.m3u8
#EXTINF:-0 tvg-id="TechStorm" tvg-name="TechStorm" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/TechStorm_new.png" group-title="AISPLAY PREMIUM",TechStorm
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"+5Bo4FFoUu4OwlFgUyLlSQ", "kid":"3KmJ73hPoxAwD6IciT288w" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0168/DASH/V0168.mpd
#EXTINF:-0 tvg-id="CrimeInvestigation" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2022/10/11/f09e41a0-492e-11ed-bb17-0527d4e1664c_webp_original.png" group-title="สารคดีความรู้",Crime Investigation TH
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/557_H2/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQzOjU4IFBNJmhhc2hfdmFsdWU9UUUwLzBZSXQ3RGIzWEJPZ2NtekpDdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzExODY0
http://playtv.my.id/play/crime.m3u8

#EXTINF:-0 tvg-id="Discovery Asia.th" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2018/12/17/978fc2da-8f65-410f-bff8-931b22c37324.png" group-title="สารคดีความรู้",Discovery Asia TH
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"F9k+BLiOwB5n4/B/aJRxZA", "kid":"x9Kzou5E0tnmdvX/HAnMVw" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0181/DASH/V0181.mpd
https://wacthstream.com/stream_live/555_Discovery_Asia/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQzOjE4IFBNJmhhc2hfdmFsdWU9Z29FNHZEc2ZOUHNYb2x6OGl3MFJmdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzMwMjc2|Referer=https://wacth.tv



#EXTINF:-1 tvg-id="LoveNature4K" tvg-name="" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/1d/Love_Nature_TV.png" group-title="สารคดีความรู้", LOVE Nature 4K
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=7d0b58f6ba324ad5bf123a8098e3ad2f:45906f0ddd1e4c28ba9e9dc138d75da8
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/501/501.mpd

#EXTINF:-0 tvg-id="OUTDOOR" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2018/12/17/f2c30832-7d77-4a24-88ad-1d30c593bda1.png" group-title="สารคดีความรู้",TH OUTDOOR
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/673_OUTDOOR/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQyOjIwIFBNJmhhc2hfdmFsdWU9SlQ2aEdNN1pwVHBaTE42RjNrVkZiQT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzM1MjU5

http://45.139.122.199/play/live.php?mac=10:27:BE:15:b9:6e&stream=115749&extension=ts&play_token=

#EXTINF:-0 tvg-id="DiscoveryChannel" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2019/10/31/6376c0b0-fbff-11e9-815f-e77857a1249b_original.png" group-title="สารคดีความรู้",TH - Discovery
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"KuAzsG4/uOOiatY/t00PLw", "kid":"foOTU3iBsthTQjjzqRbVpA" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0180/DASH/V0180.mpd
https://wacthstream.com/stream_live/562_Discovery/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQyOjUwIFBNJmhhc2hfdmFsdWU9VUs5UEhtVE5Ma0YxOUlINDhUK3R0UT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzIxMjQz|Referer=https://wacth.tv
#EXTINF:-0 group-title="สารคดีความรู้" tvg-id="TrueExploreLife.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/486c7da0-e599-11ed-b481-1b121c78e74e_webp_original.png",TH - TR EXP LIFE
#EXTVLCOPT:http-referrer=https://wacth.tv
https://sv2.wacthstream.com/wacth_tv/560_EXPLORE_LIFE/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvNi8yMDIzIDExOjE4OjI3IEFNJmhhc2hfdmFsdWU9eFpNTzhKaVdlNUlWT0NZenNVV2Izdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzIyMDI4
#https://sv2.wacthstream.com/wacth_tv/560_EXPLORE_LIFE/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTAvMTEvMjAyMyAxMToxNDo0MyBBTSZoYXNoX3ZhbHVlPWM3OUo0NXgvcmZob0VZZGxLaW8rZlE9PSZ2YWxpZG1pbnV0ZXM9ODY0MDAwMDAmc3RybV9sZW49MCZpZD1jaF83NTg0Nw==

#EXTINF:-0 group-title="สารคดีความรู้" tvg-id="TrueExploreSci.th" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/488c61b0-e599-11ed-94a2-8feec94a4a3b_webp_original.png, True Explore Sci
https://wacthstream.com/stream_live/561_TRUE_EXPLORE_SCI/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQxOjIyIFBNJmhhc2hfdmFsdWU9Y0x0dnZRcTFTVnR2akZoL0hwZ2JiUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzUxNjA5|Referer=https://wacth.tv
#https://2nud.short.gy/truesci.m3u8

#EXTINF:0 tvg-id="AnimalPlanet.Id" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//AnimalPlanet.png" group-title="สารคดีความรู้",Animal Planet TH
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"UtmKHNVPmdZ+ZRJ5lQTSNQ", "kid":"RFsSIK6zn+tVqVlErutl9A" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0182/DASH/V0182.mpd
https://wacthstream.com/stream_live/567_Animal_Planet/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQ0OjQwIFBNJmhhc2hfdmFsdWU9cHNyNXR1TzFlOGQzdWhLNllCN29qdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzQyMTY1|Referer=https://wacth.tv
#EXTINF:-0 tvg-id="TrueExploreWild.th" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/433fe010-e599-11ed-96ec-4d05b9e2ca86_webp_original.png" group-title="สารคดีความรู้",TRUE EXPLORE WILD
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net/
https://streaming.livescorethai.net/iptv/sd-expwild.stream/playlist.m3u8
EXTINF:-1 tvg-id="TR KMTV" tvg-name="" tvg-logo="http://tvsmagazine.com/images/channels/sm_KMTV.jpg" group-title="วาไรตี้",KMTV 
#https://wacthstream.com/stream_live/347_KMTV/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTEvNi8yMDIzIDE6Mzc6NDcgUE0maGFzaF92YWx1ZT1Ec3FYUnV0RndBdXVBNFFCNFphc3Z3PT0mdmFsaWRtaW51dGVzPTg2NDAwMDAwJnN0cm1fbGVuPTAmaWQ9Y2hfODIyMjk=|Referer=https://wacth.tv
#EXTINF:-1 group-title="วาไรตี้" tvg-id="BBCLifestyle.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/BBC-lifestylese.png",BBC lifestyle
https://wacthstream.com/stream_live/353_BBC_Life_Style/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM5OjI5IFBNJmhhc2hfdmFsdWU9STJmRFg2amhFWjByTDJDLzFtMk4yZz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzkyNjM1|Referer=https://wacth.tv
http://playtv.my.id/play/bbclifestyle.m3u8
#EXTINF:0 tvg-id="BBCEarth.Id" tvg-logo="https://cms.dmpcdn.com/livetv/2019/01/24/dcf08ac0-b368-4991-99ea-e07df194bf63.png" group-title="สารคดีความรู้",BBC Earth HD
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net
https://streaming.livescorethai.net/iptv/sd-bbcearth.stream/playlist.m3u8

#EXTINF:-0 group-title="สารคดีความรู้" tvg-id="" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSR5MAO5_qmfR0KjAEXSYUIPi4Oj_i6R5syg&usqp=CAU",สำรวจโลก
#EXTVLCOPT:http-user-agent=Mozilla /5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML เช่น Gecko) Chrome/55.0.2883.87 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC8/index.m3u8

#EXTINF:-0 tvg-id="History" tvg-name="HistoryHD" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/26/e0b94410-fb8a-11ed-9087-3197146bda13_webp_original.png" group-title="สารคดีความรู้",TH - HISTORY
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-history.stream/playlist.m3u8


#EXTINF:-0 group-title="วาไรตี้" tvg-id="Superbunteung.th" tvg-logo="https://cms.dmpcdn.com/livetv/2020/06/23/99bc7f60-b550-11ea-8fac-236a281cd6c5_320.png",Super บันเทิง
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/367_Super_bunteung/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM4OjQ3IFBNJmhhc2hfdmFsdWU9d0VQdkpNenloVllYSTZ0TlFKUHE1UT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzY0MDE2

#EXTINF:-0 tvg-id="AsianFoodNetwork.sg" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon//R3_0161.png" group-title="วาไรตี้",Asian Food Network
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"lDvB/4ehXpzxlhNxO+1lCQ", "kid":"QcbWBBeGv4FCY22mZGr4IQ" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0161/DASH/V0161.mpd
#https://streaming.livescorethai.net/iptv/sd-asianfood.stream/playlist.m3u8|Referer=https://freetvdd.com
#EXTINF:-0 group-title="วาไรตี้" tvg-id="" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ-sFSqdsgXoHC3H7P0kLPv9XqOnnwptbdgfQ&usqp=CAU", TrueMusic
https://wacthstream.com/stream_live/357_TrueMusic/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvNi8yMDIzIDExOjEwOjAxIEFNJmhhc2hfdmFsdWU9cUZVa1FMYmJvSVUwUXNjTkxPUDEydz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzE0Mjgx|Referer=https://wacth.tv
#EXTINF:-0 group-title="วาไรตี้" tvg-id="TLC" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Tlc_logo_discovery.svg/640px-Tlc_logo_discovery.svg.png",TLC
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"bHrvwnxL6g/RDCggYcE42A", "kid":"rf6OaqgBVZpOEpmSwPIEAw" } ], "type":"temporary" }
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0183/DASH/V0183.mpd

#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net
#https://streaming.livescorethai.net/iptv/sd-tlc.stream/chunks.m3u8
#EXTINF:-1 group-title="วาไรตี้" tvg-id="GlobalTrekker.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/GlobalTrekker.png",GlobalTrekker
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"U3VQiEDgREMqcIw/ugOMBQ", "kid":"jGe8cfxGqa+Og5rIR5T1cA" } ], "type":"temporary" }
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0023/DASH/V0023.mpd
#EXTINF:-0 tvg-id="FashionTVAsia.fr" tvg-name="" tvg-logo="https://tv.xcoshop.com/wp-content/uploads/2022/10/Fashion-HD-919-523-new.png" group-title="บันเทิง",FASHION (4K)
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://fash2043.cloudycdn.services//slive/_definst_/ftv_ftv_4k_hevc_73d_42080_default_466_hls.smil/chunklist_b10668000_t64NGs=.m3u8
#EXTINF:-0 tvg-id="" tvg-name="TH - TR INSIDE" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQ3PutcA_fmWObPcnCtAMunJP_W7BQesjzqw&usqp=CAU" group-title="บันเทิง",TH - TR INSIDE
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/335_TrueInsideHD/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM3OjAzIFBNJmhhc2hfdmFsdWU9SzhBZzltM2xRaXJURmIycitmZGY0QT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzgwODc0


#EXTINF:-1 tvg-id="3BBAsian.th" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//3BBAsian_new.png" group-title="ดูซีรีย์",3BB Asian
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=dac6cbd9d17a451bb76386f52469e0e9:2e2ac52cadf843459915eaa1a9b95e48
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/101/101.mpd

#EXTINF:-1 tvg-id="MONOPLUS.th" tvg-name="MonoPlus" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//Mono29Plus_new.png" group-title="AISPLAY PREMIUM", 3BB-MONO PLUS
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=2698a310f625b96ac6c46d5a7c8e779b:35b285a0ace10e4f4cbb7aab67c94fba
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0192/DASH/V0192.mpd
#EXTINF:-1 tvg-id="MONOPLUS.th" tvg-name="MonoPlus" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//Mono29Plus_new.png" group-title="3BBTV", 3BB-MONO PLUS
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=072eeb02f6744f838fcc8f0ef36b312e:b797c12f2dd64728aae23fd3c8ef275c
https://ubn-streamer1.cdn.3bbtv.com:8443/3bb/live/109/109.mpd
#EXTINF:1 tvg-logo="https://upload.wikimedia.org/wikipedia/en/thumb/a/a3/7flix_logo_2020.svg/440px-7flix_logo_2020.svg.png" group-title="หนังภาพยนตร์", 7Film
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC5/index.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://dl.dropbox.com/s/14iy6rp33oqdjp3/movieworld1.png?dl=0" group-title="หนังภาพยนตร์",MOVIES WORLD 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC1/index.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://dl.dropbox.com/s/14iy6rp33oqdjp3/movieworld1.png?dl=0" group-title="หนังภาพยนตร์",MOVIES WORLD 1 Sub
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC11/index.m3u8
#EXTINF:-1 tvg-id="moviesworld2" tvg-name="MOVIESWORLD2" tvg-logo="https://dl.dropbox.com/s/nsw4nfi4o5b94ko/moviesworld2.jpg?dl=0" group-title="หนังภาพยนตร์",MOVIES WORLD 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC53/index.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.vimeocdn.com/video/722791735-959381a44397842bc1f7b14dd6e7ece4e8e6d89094b12e3e829279c5980be790-d_640" group-title="หนังภาพยนตร์", Action Hollywood Movies
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://61.19.242.134/feed/eI5rczhSQpWBcgOtqRLNWw/LC26/index.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://dl.dropbox.com/s/ngewvm09401fdoo/moviesworld3.jpg?dl=0" group-title="หนังภาพยนตร์",MOVIES WORLD 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC2/index.m3u8
#EXTINF:-1 tvg-id="BoxFilm.th" tvg-name="BOX FILM" tvg-logo="https://i.imgur.com/ACIoLb2.png" group-title="หนังภาพยนตร์",BOX FILM
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC52/index.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://upload.wikimedia.org/wikipedia/en/9/99/Lotus_TV_Macau_logo.jpg" group-title="หนังภาพยนตร์", Lotus_TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://61.19.242.134/feed/eI5rczhSQpWBcgOtqRLNWw/LC41/index.m3u8
#EXTINF:-1 tvg-id="MOVIES WORLD 1" tvg-name="MOVIES WORLD 1" tvg-logo="https://i.postimg.cc/63hYNwt4/MOVIESWORLD1.jpg" group-title="หนังภาพยนตร์",MOVIES WORLD 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC11/index.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0039.png" group-title="หนังภาพยนตร์",แอท ทีวี
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0039/HLS/V0039.m3u8
#EXTINF:-1 tvg-id="Mangorn" tvg-name="Mangorn" tvg-logo="https://i.imgur.com/vMWjnIm.png" group-title="หนังภาพยนตร์",MANGORN
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://49.0.87.24:1936/HDDragon/Dragon/playlist.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.imgur.com/i7HCIuZ.jpg" group-title="หนังภาพยนตร์",Jomyut
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://49.0.87.24:1936/HDJomyut/Jomyut/playlist.m3u8
#EXTINF:-1 tvg-id="Thrill.hk" tvg-name="Thrill" tvg-logo="https://i.imgur.com/7M6WYVm.png" group-title="หนังภาพยนตร์",Thrill
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://210.210.155.35/session/c8a974dc-7e3d-11e8-bf09-b82a72d63267/qwr9ew/s/s34/01.m3u8
#EXTINF:-0 tvg-id="" tvg-name="Blue Ant Extreme" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/RockAction.png" group-title="หนังภาพยนตร์",Rock Action
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=4a3f4f0914988cc2f6be128c28893fff:db158f0d2bb85efd8f06e38d483de19c
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0166/DASH/V0166.mpd
https://wacthstream.com/stream_live/338_Rock_Extreme/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQ1OjUzIFBNJmhhc2hfdmFsdWU9WjJWcDBuQjBMbVhJL2xhTzdtbnp1dz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzMzODQx|Referer=https://wacth.tv

#EXTINF:-0 tvg-id="RockEntertainment.sg" tvg-name="Rock Extreme" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/Rock-Entertainment.png" group-title="หนังภาพยนตร์",Rock Entertainment
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=3837d26526efca2fa1f18823bd073c0f:ab4d56168a618b2413beb137d70ac453
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0165/DASH/V0165.mpd
#https://wacthstream.com/stream_live/337_Rock_Entertainment/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjQ1OjM5IFBNJmhhc2hfdmFsdWU9enRaZFY0M1dueHQzaGpoTVVSSlludz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzkzNzk4|Referer=https://wacth.tv

#EXTINF:-0 tvg-id="Lifetime" tvg-name="TH - LIFETIME" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/26/e2540850-fb8a-11ed-b4ef-f5e84d65e5d3_webp_original.png" group-title="บันเทิง",Lifetime TH 
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-lifetime.stream/playlist.m3u8
#EXTINF:-0 tvg-id="tvbs" tvg-name="TVBS" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/TVBS.png" group-title="บันเทิง", TVBS
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0108/DASH/V0108.mpd
#EXTINF:-0 tvg-id="Mono29Musicstation." tvg-name="Mono29Musicstation" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//Mono29Music_new.png" group-title="บันเทิง", Mono29Musicstation
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=2355ee65664e0b7fc02e7d389e1d2658:a935ccb1065ffe214823aae414f8b257
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0193/DASH/V0193.mpd
#EXTINF:-0 tvg-id="TrueXZyte.th" tvg-name="True X-Zyte" tvg-logo="https://cms.dmpcdn.com/livetv/2022/01/12/2a450650-7374-11ec-91d2-797a50c5a656_webp_320.png" group-title="วาไรตี้",TH - TR X-ZYTE
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net
https://streaming.livescorethai.net/iptv/hd-xzyte.stream/playlist.m3u8


#EXTINF:-0 tvg-id="FoodNetworkAsia.sg" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0162.png" group-title="วาไรตี้",Food Network
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=7372347ddf65ab1594ee35362240dafa:4d78d33c15d1098214b3d3cd3bb7c2a4
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0162/DASH/V0162.mpd
#https://streaming.livescorethai.net/iptv/sd-asianfood.stream/playlist.m3u8|Referer=https://freetvdd.com/



#EXTINF:-0 tvg-id="TrueFilmHD1.th" tvg-name="TH - TR FILM HD" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/43f28e40-e599-11ed-844f-795506bf0bf9_webp_original.png" group-title="หนังภาพยนตร์",TH - TR FILM HD1
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/hd-tfilm.stream/playlist.m3u8
https://ctrl.laotv.la/live/TureFilm/index.m3u8

#EXTINF:-1 tvg-id="TrueFilmHD2.th" tvg-name="TrueFilmHD2" tvg-logo="https://i.imgur.com/QaVqmK1.png" group-title="หนังภาพยนตร์",True Film 2
http://playtv.my.id/play/truefilm2.m3u8


#EXTINF:-0 tvg-id="TrueMovieHits.th" tvg-name="True Movie Hits" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/45345d10-e599-11ed-86b8-bb40638e3c49_webp_original.png" group-title="หนังภาพยนตร์",True TrueMovieHits
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/sd-moviehits.stream/playlist.m3u8


#EXTINF:-1 group-title="ดูซีรีย์" tvg-logo="https://wacth.officebk.co/uploads/tv_image/20231214211508kmtv.png", KMTV 
https://wacthstream.com/stream_live/347_KMTV/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjE2OjA4IFBNJmhhc2hfdmFsdWU9bEVadi9ZY0pjVVNXbXZlUWdMZUp0dz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzMwMjE0|Referer=https://wacth.tv
#EXTINF:-1 group-title="ดูซีรีย์" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/434696d0-e599-11ed-b26c-6b89d082d464_webp_original.png", True Film Asia
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://streaming.livescorethai.net/iptv/sd-filmasia.stream/playlist.m3u8|Referer=https://freetvdd.com/

#EXTVLCOPT:http-referrer=https://wacth.tv/
#EXTVLCOPT:http-user-agent=Mozilla /5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML เช่น Gecko) Chrome/55.0.2883.87 Safari/537.36
https://wacthstream.com/stream_live/237_TrueFilmAsia/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjIxOjAwIFBNJmhhc2hfdmFsdWU9SGI0WWM4NzE1d2k3eENBRW5CNXlSUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzMxOTY2

#EXTINF:-0 tvg-id="KBSWorld" tvg-name="KBS World" tvg-logo="https://cms.dmpcdn.com/livetv/2023/05/26/e13eeed0-fb8a-11ed-9087-3197146bda13_webp_original.png" group-title="ดูซีรีย์",KBS World
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/245_KBS/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjIzOjU2IFBNJmhhc2hfdmFsdWU9SW5DUWVPT0kyZWQvQnBpeWpRY1VaQT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzI1Njg2

#EXTINF:-0 tvg-id="ParamountNetwork.sg" tvg-name="Paramount Network" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//LOGO_Paramount2.png" group-title="หนังภาพยนตร์",Paramount Network
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=25bf32f14fa2141acb7d008c0c438bc8:e8b12304c39c113f97de330a27887b31
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0185/DASH/V0185.mpd
#https://wacthstream.com/stream_live/232_Paramount/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI0OjQxIFBNJmhhc2hfdmFsdWU9UDdaaW80eHo0MktLLzNxZ1RNYXJRUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzcxOTEy


#EXTINF:-0 tvg-id="TrueAsianMore.th" tvg-name="" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/47a53600-e599-11ed-94a2-8feec94a4a3b_webp_original.webp" group-title="ดูซีรีย์",TrueAsianMore
#EXTVLCOPT:http-user-agent=Mozilla /5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML เช่น Gecko) Chrome/55.0.2883.87 Safari/537.36
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/239_AsianMore/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI1OjIwIFBNJmhhc2hfdmFsdWU9WjNjYi9HN25zVHlyYTFMWEFUMVRmdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzc2NzQ3
#http://playtv.my.id/play/asianmoresd.m3u8
#EXTINF:-0 tvg-id="trueseries.th" tvg-name="trueseries" tvg-logo="https://cms.dmpcdn.com/livetv/2023/04/28/456c5d00-e599-11ed-b550-9935ba8025b9_webp_original.png" group-title="ดูซีรีย์",TrueSeries
#EXTVLCOPT:http-referrer=https://freetvdd.com
https://streaming.livescorethai.net/iptv/sd-series.stream/playlist.m3u8
https://wacthstream.com/stream_live/240_True_Series/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI2OjE3IFBNJmhhc2hfdmFsdWU9dStiVVkxN0M1MkpYS0hTeUFSaGVMUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzYxNDY0|Referer=https://wacth.tv
#EXTINF:-0 tvg-id="tvN" tvg-name="Entertainment" tvg-logo="https://truevisions.co.th/static/891ab984-b696-4284-a9df-9cb412fe8c84.png" group-title="ดูซีรีย์",TVN HD
https://streaming.livescorethai.net/iptv/hd-tvn.stream/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9My8xMC8yMDIwIDY6Mjg6MDEgQU0maGFzaF92YWx1ZT0xY0RZT3RydjNwdk9JRjROcGhJbU1RPT0mdmFsaWRtaW51dGVzPTIwJnN0cm1fbGVuPTIw|Referer=https://streaming.livescorethai.net
http://198.16.100.90:8278/TVN/playlist.m3u8?tid=ME8E2207086222070862&ct=19249&tsum=b7f602e68174a03e917c7b354788bce9
#EXTINF:-0 tvg-id="GEM" tvg-name="Gem" tvg-logo="https://cms.dmpcdn.com/livetv/2020/03/17/46466450-6842-11ea-a7cd-dd316e61efc7_original.png" group-title="ดูซีรีย์",TH GEM
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/244_GEM/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI2OjUyIFBNJmhhc2hfdmFsdWU9VTZ2c3lBeHVmd291dzVreTliK3dGUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzczMjE3

#EXTINF:-0 tvg-id="truemusic.th" tvg-name="TRUE MUSIC" tvg-logo="https://freetvdd.com/wp-content/uploads/2019/12/true-music-hd.png" group-title="Music",TrueMusic
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/357_TrueMusic/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI4OjA1IFBNJmhhc2hfdmFsdWU9Rm9zZHUzeUZCNmhGK05hVGpVOVFlUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzc4NTMy

#EXTINF:1 tvg-logo="https://cms.dmpcdn.com/livetv/2023/11/13/bd6a6d20-8205-11ee-822c-6bbb3f82c35b_webp_original.webp" group-title="News", voice TV
#EXTVLCOPT:http-referrer=https://www.ballhd24.live/
https://2nud.short.gy/voicetv.m3u8
EXTINF:1 tvg-logo="https://cms.dmpcdn.com/livetv/2023/11/13/bd6a6d20-8205-11ee-822c-6bbb3f82c35b_webp_original.webp" group-title="TV DIGITAL", voice TV
#EXTVLCOPT:http-referrer=https://www.ballhd24.live/
#https://2nud.short.gy/voicetv.m3u8
#EXTINF:1 tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0036.png" group-title="News", NEWS 1
#EXTVLCOPT:http-user-agent=VLC/3.0.9 LibVLC/3.0.9
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0036/HLS/V0036.m3u8

#EXTINF:1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/f/fe/Cropped-topnews-logo.png" group-title="News", TOP NEWS
https://live.topnews.co.th/hls/topnews_a_720.m3u8

#EXTINF:1 tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0107.png" group-title="AISPLAY PREMIUM", HLN
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=f5e2d32a4acc84af9770faba8a7ff1fa:7b0b64c86be296d15ebdf3a3a1af0560
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0107/DASH/V0107.mpd



#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC24/playlist.m3u8
#EXTINF:1 tvg-logo="https://english-club.tv/wp-content/uploads/2015/09/logo-round.png" group-title="วาไรตี้", English club
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC21/index.m3u8
#EXTINF:-0 tvg-id="CNBCAsia.sg" group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/CNBC.png",CNBC
#EXTVLCOPT:http-referrer=https://freetvdd.com/
https://streaming.livescorethai.net/iptv/sd-cnbc.stream/chunks.m3u8
#EXTINF:-1 tvg-id="CCTV4" tvg-name="CCTV4" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/CCTV4.png" group-title="News",CCTV4
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC33/index.m3u8
#EXTINF:-1 tvg-id="ArirangTV.kr" tvg-name="arirang" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//0177.png" group-title="News",Arirang
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0177/HLS/V0177.m3u8
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://freetvdd.com/wp-content/uploads/2019/12/tv5monde.png" group-title="News",TV5 Monde
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0141/HLS/V0141.m3u8

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC10/index.m3u8

#EXTINF:-1 tvg-id="CNNIndonesia.id" tvg-name="" tvg-logo="hhttps://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0172.png" group-title="News",CNN HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#http://playtv.my.id/play/cnn.m3u8
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://tv.realmetx.repl.co/Ch/license/cnn.html
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0172/DASH/V0172.mpd



#EXTINF:-1 tvg-id="Al Jazeera English HD" tvg-name="AlJazeeraEnglish" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//Aljazeera_logo.png", group-title="News",Al Jazeera 
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0140/HLS/V0140.m3u8

#EXTINF:-1 tvg-id="RTDocumentary.th" tvg-name="RT Documentary" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//RTDocumentary.png", group-title="News",RT Documentary
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0105/HLS/V0105.m3u8

EXTINF:-1 tvg-id="ABCAustralia.au" tvg-name="" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGyNahtudGwhDpp_J39ao3e5jCLeWJrDcakg&usqp=CAU", group-title="News", ABC News
#http://50.7.238.114:8278/abcnews_glo/playlist.m3u8?tid=MAEA6759929367599293&ct=19225&tsum=edd59704e2182262583ea5b0e1093b9d
#https://bit.ly/3rN3hd9
#https://content.uplynk.com/channel/3324f2467c414329b3b0cc5cd987b6be.m3u8

#EXTINF:-1 tvg-id="CGTN" tvg-name="" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/CGTN.png", group-title="News",CGTN
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0174/HLS/V0174.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" group-title="วาไรตี้" tvg-logo="https://upload.wikimedia.org/wikipedia/en/a/a5/Style_Network_2012_Logo.png", Style 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC25/index.m3u8
#EXTINF:-1 group-title="AISPLAY PREMIUM" tvg-id="BBC News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/BBCNEWS.png",BBCNews
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=0e7078457bda703b567e3fbfa46ffaac:116c7d0b1960bf398798a09a75ee155b
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0125/DASH/V0125.mpd

#EXTINF:-1 group-title="News" tvg-id="BBC News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/BBCNEWS.png",BBCNEWS
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=0e7078457bda703b567e3fbfa46ffaac:116c7d0b1960bf398798a09a75ee155b
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0125/DASH/V0125.mpd

#EXTINF:-1 tvg-id="CNA" tvg-name="CNA"  group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon/R_0122.png",CNA
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0122/HLS/V0122.m3u8

#EXTINF:-1 tvg-id="DWEnglish.id", group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon/0121",DW English
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0121/HLS/V0121.m3u8
#EXTINF:-1 tvg-id="" group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon/0119.png",EuroNews English
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0119/HLS/V0119.m3u8
#EXTINF:-1 tvg-id="france24g.ru", group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon/0123_1.png",France24
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0123/HLS/V0123.m3u8
#EXTINF:-1 tvg-id="NHKWorldPremium" , group-title="News" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/LOGO_NHK_new.png",NHK World Premium
#EXTVLCOPT:http-referrer=https://ais-vidnt.com/
https://49-231-37-37-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0102/HLS/V0102.m3u8

EXTINF:-1 group-title="News" tvg-id="" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/CBS_News.svg/1600px-CBS_News.svg.png",CBS
http://50.7.238.114:8278/cbsn_glo/playlist.m3u8?tid=ME2E7003518970035189&ct=19225&tsum=c1cc67ff59df6d6f608a400760be0bda



EXTINF:-1 group-title="ช่องเด็ก" tvg-logo="https://i.ytimg.com/vi/Zn1yvsGD-TU/maxresdefault.jpg",BabyBus
#https://livestream.zazerconer.workers.dev/channel/UCKpFt-Nh3A2Sg--mLmCebZQ.m3u8

EXTINF:-1 group-title="ช่องเด็ก" tvg-logo="https://yt3.ggpht.com/P9Njluo4AsKyXYaxltiYxF4LrURIIOBZwdn9JlSEd4yiSrscBe3SpRittk5Gif8JbFst4zNWZA=s88-c-k-c0x00ffffff-no-rj",My Little Pony
#https://livestream.zazerconer.workers.dev/channel/UCOT9qiUmk4mk-B_hN__toTw.m3u8
EXTINF:-1 group-title="ช่องเด็ก"   tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVfKsOCHZW1jzOsGZydivGZP2ZDwROxtPdWQ&usqp=CAU",Disney Junior NO 24/7
#http://live.maxcimo.com:8000/live/live%3Aicnsocial/547ghf828fghfxd96/2605.ts
#https://livestream.zazerconer.workers.dev/channel/UCNcdbMyA59zE-Vk668bKWOg.m3u8
#EXTINF:-1 group-title="ช่องเด็ก" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNbxe5sIiySX5-PgYL5nGo334cNGlHE8D4EQ&usqp=CAU" ,BabyBus - Kids Songs and Cartoons
https://livestream.zazerconer.workers.dev/channel/UCpYye8D5fFMUPf9nSfgd4bA.m3u8

#EXTINF:-1 group-title="ช่องเด็ก" tvg-id="Cartoonito.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//Cartoonito.png",Cartoonito
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=d6a1b556425b6932c6ffe80e7a828e57:bd8ea11b338954c1746f45bcf851c91e
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0113/DASH/V0113.mpd
#EXTINF:-1 group-title="ช่องเด็ก" tvg-id="Cartoonito.th" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon//Cartoonito.png",Cartoonito US
https://streaming.livescorethai.net/iptv/uk-cartoonito.stream/chunks.m3u8|Referer=https://freetvdd.com


#EXTINF:-1 group-title="ช่องเด็ก" tvg-id="nickjr" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/0156.png",Nick Jr
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=d4852cf0a609a4f7f21bac4a4f7d5df5:a47711e6e3d68235cc942e4fb9c1c5f1
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0186/DASH/V0186.mpd


#EXTINF:-1 group-title="ช่องเด็ก" tvg-id="nickelodeonasia.sg" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE//channelicon/LOGO_Nickelodeon2.png",Nickelodeon
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=34cf6695d9082bc5b4687e59d61b48d2:64e30dc5efbacf1f3fd344a01ba2f906
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0187/DASH/V0187.mpd

#EXTINF:-1 tvg-id="BOOMERANG.th" tvg-name="BOOMERANG" tvg-logo="https://i.imgur.com/Ruc88XO.png" group-title="ช่องเด็ก",BOOMERANG
TH
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chboomberang/index.m3u8
#EXTINF:-1 tvg-id="CARTOONCLUB.th" tvg-name="CARTOON CLUB" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/0100.png" group-title="ช่องเด็ก",CARTOON CLUB
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://edge2-bkk.3bb.co.th:9443/Web_CartoonClub_Live/cartoonclub_480P.stream/chunklist.m3u8

#EXTINF:-1 tvg-id="ZooMoo.th" tvg-name="ZooMoo" tvg-logo="https://i.imgur.com/olzqUL2.jpg" group-title="ช่องเด็ก",ZooMoo
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC38/index.m3u8

#EXTINF:-0 group-title="ช่องเด็ก" tvg-id="Boomerang (Asia)" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE/channelicon/Boomerang_2.png",Boomerang (Thai)
#EXTVLCOPT:http-user-agent=Mozilla /5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML เช่น Gecko) Chrome/55.0.2883.87 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chboomberang/index.m3u8
#EXTINF:-0 tvg-id="Cartoon Network.th" tvg-name="Cartoon Network" tvg-logo="https://ais-s.ais-vidnt.com/ais/play/origin/LIVE///channelicon//0171.png" group-title="ช่องเด็ก",Cartoon Network TH 
https://streaming.livescorethai.net/iptv/sd-cartoonnetwork.stream/playlist.m3u8|Referer=https://freetvdd.com
https://wacthstream.com/stream_live/449_Carton_Netwrk/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI5OjU4IFBNJmhhc2hfdmFsdWU9Ym5xM2JIYWxaSFNCQXdrTXJoWlgwUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzY5NDk0|Referer=https://wacth.tv

#EXTINF:-0 tvg-id="" tvg-name="DreamWorks TV HD" tvg-logo="https://iptv-pro.github.io/logo/DREAMWORKS.png" group-title="ช่องเด็ก",DreamWorks 
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/448_DreamWorks/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI5OjI2IFBNJmhhc2hfdmFsdWU9d1hCZVJRdmViSzZuQXAwRWJVS0xqdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzQ2MzEy

#http://playtv.my.id/play/dreamworld.m3u8
#https://live.khanggtivi.xyz/hls_vod/1080p/f671311e73e05d23eb6d85468d1ce5b3f05382c812629f2026174b9eaee34b6f95aa57/dreamworks/index.m3u8
#EXTINF:-0 tvg-id="" tvg-name="TH - TR SPARK PLAY" tvg-logo="https://images.livebox.co/images/tv/png/sd-sparkplay.png" group-title="ช่องเด็ก",TH - TR SPARK PLAY
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/445_SparkJump/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjI5OjQ2IFBNJmhhc2hfdmFsdWU9Nks5dFZIWkpFQUlqR0xJaUxweVIvUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzc1MDUx
http://playtv.my.id/play/spark.m3u8


EXTINF:1 tvg-id="aniplus.th" group-title="ช่องเด็ก" tvg-logo="https://gdplayertv.top/assets/img/logo/aniplus.png", ANIPLUS
#EXTVLCOPT:http-origin=https://gdplayertv.top
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#https://idx.iptvfreemium.com/denslokal/h/h114/S4/mnf.m3u8?app_type=web&userid=jjj&chname=ANIPLUS_HD

#http://45.139.122.199/play/live.php?mac=10:27:BE:15:b9:6e&stream=115529&,=ts&play_token=
#EXTVLCOPT:http-referrer=https://wacth.tv/
#https://wacthstream.com/stream_live/445_SparkJump/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTEvNi8yMDIzIDE6NTA6NTkgUE0maGFzaF92YWx1ZT13ZmZ6Uk82K2ZNMlU1TTdJUkIxNnR3PT0mdmFsaWRtaW51dGVzPTg2NDAwMDAwJnN0cm1fbGVuPTAmaWQ9Y2hfNjU1OTI=


#EXTINF:-1 tvg-id="Khongdee.th" tvg-name="KhongDee" tvg-logo="https://i.ibb.co/Pg7dBL9/ddd.png" group-title="กู๊ดทีวี",KhongDee
https://49-231-37-237-rewriter.ais-vidnt.com/ais/play/origin/live/eds/V0154/HLS/V0154.m3u8
https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/V0154/DASH/V0154.mpd


#EXTINF:-1 tvg-id="Budsaba.th" tvg-name="Busaba" tvg-logo="https://i.ibb.co/7SRycDD/bbb.png" group-title="กู๊ดทีวี",Busaba
#EXTVLCOPT:http-referrer=https://wacth.tv
https://wacthstream.com/stream_live/goodtv38_Busaba./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMxOjA3IFBNJmhhc2hfdmFsdWU9MCtQRVYxRkpXR01TK05UVlZNZlhFUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzQ3Nzc3
#EXTINF:-1 tvg-id="JustFun.th" tvg-name="JustFun" tvg-logo="https://i.ibb.co/dsNNJ3L/Justfun.png" group-title="กู๊ดทีวี",JustFun
#EXTVLCOPT:http-referrer=https://wacth.tv
https://wacthstream.com/stream_live/goodtv39_JustFun./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMxOjI1IFBNJmhhc2hfdmFsdWU9WUwvSEdsRXR5b3hPb3RISHYrbGZHUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzYwODQ5
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://wacth.officebk.co/uploads/tv_image/20220113190044thainess.png" group-title="กู๊ดทีวี",Thainess
#EXTVLCOPT:http-referrer=https://wacth.tv/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://wacthstream.com/stream_live/goodtv40_ThaiNess./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMxOjU1IFBNJmhhc2hfdmFsdWU9V3JpZjArL0pKNWtZbExxcGdvZ1NRUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzg3NzE4
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.ibb.co/tXr6CPL/sweet.png" group-title="กู๊ดทีวี",Sweet
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC58/index.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.ibb.co/tXr6CPL/sweet.png" group-title="Music",Sweet
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://wacthstream.com/stream_live/goodtv42_Sweet./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM1OjI5IFBNJmhhc2hfdmFsdWU9Y2lST1NQbjY3cmM0ZzBkN291cGFJUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzQ2MzIw|Referer=https://wacth.tv
#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://wacth.officebk.co/uploads/tv_image/20220113185953realmetro.png" group-title="กู๊ดทีวี",Real Metro2
#EXTVLCOPT:http-referrer=https://wacth.tv/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://wacthstream.com/stream_live/goodtv41_RealMetro./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMyOjI2IFBNJmhhc2hfdmFsdWU9VWw0RUppNjN0RzhWWk5Pck43Z3Azdz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzIzNTU3

#EXTINF:-1 tvg-id="Heart.th" tvg-name="Heart" tvg-logo="https://i.ibb.co/qYHStJ0/heart.png" group-title="กู๊ดทีวี",Heart
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/goodtv43_Heart./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMyOjQyIFBNJmhhc2hfdmFsdWU9QXZLVldqdE1oZHduVVZ1SVZEQzFxUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzYxNzYy
#EXTINF:-1 tvg-id="Hero.th" tvg-name="Hero" tvg-logo="https://i.ibb.co/S3LPy31/Hero.png" group-title="กู๊ดทีวี",Hero
#EXTVLCOPT:http-referrer=https://wacth.tv
https://wacthstream.com/stream_live/goodtv44_Hero./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMzOjA0IFBNJmhhc2hfdmFsdWU9Z3hGeDZKWlg3RThWOUxJdm40bFlldz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzc2MzU2
#EXTINF:-1 tvg-id="Sumlojlok.th" tvg-name="Sumlojlok" tvg-logo="https://i.ibb.co/Pm84NSc/goodtv.jpg" group-title="กู๊ดทีวี",Sumlojlok
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC8/index.m3u8
#EXTINF:-1 tvg-id="animalshow.th" tvg-name="AnimalShow" tvg-logo="https://i.ibb.co/T018CMK/animal.jpg" group-title="กู๊ดทีวี",AnimalShow
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
#EXTVLCOPT:http-referrer=https://wacth.tv
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC18/index.m3u8
#EXTINF:-1 tvg-id="animalshow.th" tvg-name="AnimalShow" tvg-logo="https://i.ibb.co/T018CMK/animal.jpg" group-title="กู๊ดทีวี",AnimalShow
#EXTVLCOPT:http-referrer=https://wacth.tv
https://wacthstream.com/stream_live/goodtv56_AnimalShow./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMzOjQ0IFBNJmhhc2hfdmFsdWU9dG00VXhoQkx4TjJwUXZ1S05odTN4QT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzE0OTk3
#EXTINF:-1 tvg-id="BXcite.th" tvg-name="BXcite" tvg-logo="https://i.ibb.co/0ZXqLCb/bxcite.png" group-title="กู๊ดทีวี",BXcite
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/goodtv57_BXcite./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjMzOjU3IFBNJmhhc2hfdmFsdWU9VEw0U003K2FrOFlkWk1zNTZuUWVDQT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzQzMzQ4
#EXTINF:-1 tvg-id="mysci.th" tvg-name="MYSCI" tvg-logo="https://wacth.officebk.co/uploads/tv_image/20220113185546mysci.png" group-title="กู๊ดทีวี",MYSCI
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/LC37/index.m3u8

#EXTINF:-1 tvg-id="NewExplorer.th" tvg-name="NewExplorer.th" tvg-logo="https://i.ibb.co/NZB9D3z/newexplore.png" group-title="กู๊ดทีวี",NewExplorer
#EXTVLCOPT:http-referrer=https://wacth.tv/
https://wacthstream.com/stream_live/goodtv59_New_Explorer./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM0OjA4IFBNJmhhc2hfdmFsdWU9RStDY0JkcnVEWDF3OWlBM2FDRFEzUT09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzU0Nzk3
#EXTINF:-1 tvg-id="NextKid.th" tvg-name="nextKids" tvg-logo="https://i.ibb.co/GC2XbHr/nextKids.jpg" group-title="กู๊ดทีวี",nextKids
#EXTVLCOPT:http-referrer=https://wacth.tv/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://wacthstream.com/stream_live/goodtv66_nextKid./playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9MTIvMTcvMjAyMyA2OjM1OjAyIFBNJmhhc2hfdmFsdWU9MmIvUDdJYmtrdWt4bThZZE5SN1RCZz09JnZhbGlkbWludXRlcz04NjQwMDAwMCZzdHJtX2xlbj0wJmlkPWNoXzU3MDU4
#EXTM3U

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport1serbia.rs" tvg-logo="https://www.tvarenasport.si/uploads/web/arenasport1.png",Arena Sport 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://rr5---sn-w5nuxa-c33lk-14.googleuservideo.com/ballhd24liv_e4/arenasport1serbia/chunks.m3u8
#https://webudit.hlsjs.ru/lb/premium429/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport2serbia.rs" tvg-logo="https://www.tvarenasport.si/uploads/web/arenasport2.png",Arena Sport 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium433/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport3serbia.rs" tvg-logo="https://www.tvarenasport.si/uploads/web/arenasport3.png",Arena Sport 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium434/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport1premiumserbia.rs" tvg-logo="https://i.imgur.com/4KFUlzq.png",Arena Sport Premium 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium134/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport2premiumserbia.rs" tvg-logo="https://i.imgur.com/KH1FSo2.png",Arena Sport Premium 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium135/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="arenasport3premiumserbia.rs" tvg-logo="https://i.imgur.com/0omg8RO.png",Arena Sport Premium 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium139/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astroarena.my" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/7/72/Astro_Arena.png",Astro Arena 1


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrocricket.my" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/b/b7/Astro_Cricket.png",Astro Cricket
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrocricket.my" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/b/b7/Astro_Cricket.png",Astro Cricket
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium370/index.m3u8|referer=https://streamservicehd.click/



#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrosupersport.my" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/7d/Astro_SuperSport_1.png/revision/latest?cb=20200922172456",Astro SuperSport 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium123/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrosupersport2.my" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/6/6b/Astro_SuperSport_2.png/revision/latest?cb=20200924173634",Astro SuperSport 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium124/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrosupersport3.my" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/e/e7/Astro_SuperSport_3.png/revision/latest?cb=20200924173711",Astro SuperSport 3
#EXTVLCOPT:http-referrer=https://weblivehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium125/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrosupersport4.my" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/d/d4/Astro_SuperSport_4.png/revision/latest?cb=20200924173748",Astro SuperSport 4
#EXTVLCOPT:http-referrer=https://weblivehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium126/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="astrosupersport4.my" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/6/6c/AstroSupersport5Flat.png/revision/latest?cb=20220421064927",Astro SuperSport 5
https://rr5---sn-w5nuxa-c33lk-14.googleuservideo.com/ballhd24liv_e4/astrosupersport5/chunks.m3u8
#http://mix-dns.com:8080/live/lillie.johnson11%40gmail.com/r3yUNMHHwr/485569.ts
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="btsport1.uk" tvg-logo="https://img01.products.bt.co.uk/content/dam/bt/portal/images/logos/channel-logo/full-logo/2022/BTSPORT_1_2018_WHITE_RGB.png",BT Sports 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium31/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="btsport2.uk" tvg-logo="https://img01.products.bt.co.uk/content/dam/bt/portal/images/logos/channel-logo/full-logo/2022/BTSPORT_2_2018_WHITE_RGB.png",BT Sports 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium32/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="btsport3.uk" tvg-logo="https://img01.products.bt.co.uk/content/dam/bt/portal/images/logos/channel-logo/full-logo/2022/BTSPORT_3_2018_WHITE_RGB.png",BT Sports 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium33/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="btsport4.uk" tvg-logo="https://img01.products.bt.co.uk/content/dam/bt/portal/images/logos/channel-logo/full-logo/2022/BTSPORT_4_2022_WHITE_RGB.png",BT Sports 4
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium34/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="" tvg-logo="https://gdplayer.tv/assets/img/logo/eurosport-1.png",Euro Sport 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium41/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="cctv5plus.cn" tvg-logo="https://gdplayer.tv/assets/img/logo/eurosport-2.png",Euro Sport 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium42/index.m3u8
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="elevensports1poland.pl" tvg-logo="https://ocdn.eu/ptv2-images/logo-migrated/eleven-sports-1.png",Eleven Sports 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium71/index.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="elevensports2poland.pl" tvg-logo="https://ocdn.eu/ptv2-images/logo-migrated/eleven-sports-2.png",Eleven Sports 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium72/index.m3u8|

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="elevensports3poland.pl" tvg-logo="https://ocdn.eu/ptv2-images/logo-migrated/eleven-sports-3-hd.png",Eleven Sports 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium428/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="espn.us" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/ESPN_wordmark.svg/640px-ESPN_wordmark.svg.png",ESPN 1 US
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium44/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="espn2.us" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/ESPN2_logo.svg/640px-ESPN2_logo.svg.png",ESPN 2 US
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium45/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="espndeportes.us" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Espn_deportes.svg/640px-Espn_deportes.svg.png",ESPN Deportes
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium375/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT



#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="eurosport1uk.uk" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Eurosport_1_Logo_2015.svg/640px-Eurosport_1_Logo_2015.svg.png",EuroSport 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium524/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="eurosport2uk.uk" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Eurosport_2_Logo_2015.svg/640px-Eurosport_2_Logo_2015.svg.png",EuroSport 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium525/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="foxsports1.us" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZWp5rqstiPrHw6LyRBzN7O5dG1RyOcRn8YA&usqp=CAU",FOX Sports WWE 
#EXTVLCOPT:http-referrer=https://streaming.livescorethai.net/
https://streaming.livescorethai.net/iptv/us-foxsports2.stream/playlist.m3u8?wmsAuthSign=c2VydmVyX3RpbWU9My8xMC8yMDIwIDY6Mjg6MDEgQU0maGFzaF92YWx1ZT0xY0RZT3RydjNwdk9JRjROcGhJbU1RPT0mdmFsaWRtaW51dGVzPTIwJnN0cm1fbGVuPTIw
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium39/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsaction.uk" tvg-logo="https://i.imgur.com/XlASTQb.png",Sky Sports Action
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium37/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsarena.uk" tvg-logo="https://i.imgur.com/m01PzKx.png",Sky Sports Arena
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium36/index.m3u8?

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportscricket.uk" tvg-logo="https://i.imgur.com/EoYFmY3.png",Sky Sports Cricket
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium65/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsf1.uk" tvg-logo="https://i.imgur.com/PsdeNhE.png",Sky Sports F1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium60/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsfootball.uk" tvg-logo="https://i.imgur.com/Q0P923u.png",Sky Sports Football
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium35/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsgolf.uk" tvg-logo="https://i.imgur.com/fFcM6UT.png",Sky Sports Golf
https://webudit.hlsjs.ru/lb/premium123/index.m3u8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium70/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsmainevent.uk" tvg-logo="https://i.imgur.com/xtcDjVf.png",Sky Sports Main Event
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium38/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportsmix.uk" tvg-logo="https://i.imgur.com/6ndlrZ1.png",Sky Sports Mix
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium449/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="skysportspremierleague.uk" tvg-logo="https://i.imgur.com/DSrBVhv.png",Sky Sports Premier League
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium130/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sonyten1.in" tvg-logo="https://dtat2ks7dludr.cloudfront.net/spnsportsindia/channel_logos/SONY_SportsTen1_HD.png",Sony Sports 1
https://dai.google.com/linear/hls/event/wG75n5U8RrOKiFzaWObXbA/master.m3u8


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sonyten2.in" tvg-logo="https://dtat2ks7dludr.cloudfront.net/spnsportsindia/channel_logos/SONY_SportsTen2_HD.png",Sony Sports 2
https://dai.google.com/linear/hls/event/V9h-iyOxRiGp41ppQScDSQ/master.m3u8


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sonyten3.in" tvg-logo="https://dtat2ks7dludr.cloudfront.net/spnsportsindia/channel_logos/SONY_SportsTen3_HD.png",Sony Sports 3
https://2nud.short.gy/sonyten3.m3u8


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sonyten4.in" tvg-logo="https://dtat2ks7dludr.cloudfront.net/spnsportsindia/channel_logos/SONY_SportsTen4_HD.png",SonyTen 4
https://dai.google.com/linear/hls/event/smYybI_JToWaHzwoxSE9qA/master.m3u8

#
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sonysix.in" tvg-logo="https://dtat2ks7dludr.cloudfront.net/spnsportsindia/channel_logos/SONY_SportsTen5_HD.png",SonyTen 5
https://dai.google.com/linear/hls/event/Sle_TR8rQIuZHWzshEXYjQ/master.m3u8

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportaction.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-action.png",SuperSport Action
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium420/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportfootball.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-football.png",SuperSport Football
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium56/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportgrandstand.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-grandstand.png",SuperSport GrandStand
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium412/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportgolf.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-golf.png",SuperSport Golf
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium422/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportlaliga.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-la-liga.png",SuperSport La Liga
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium415/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportmotorsport.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-motorsport.png",SuperSport Motorsport
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium424/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportpremierleague.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-premier-league.png",SuperSport Premier League
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium414/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportpsl.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-psl.png",SuperSport PSL
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium413/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportrugby.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-rugby.png",SuperSport Rugby
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium421/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersporttennis.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-tennis.png",SuperSport Tennis
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium423/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportvariety.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-variety-1.png",SuperSport Variety 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium416/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportvariety2.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-variety-2.png",SuperSport Variety 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
https://webudit.hlsjs.ru/lb/premium417/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportvariety3.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-variety-3.png",SuperSport Variety 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium418/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="supersportvariety4.za" tvg-logo="https://supersport.azureedge.net/web-assets/channels/hos/supersport-variety-4.png",SuperSport Variety 4
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webudit.hlsjs.ru/lb/premium419/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tennischannel.us" tvg-logo="https://i.imgur.com/VWQk2S1.png",Tennis Channel
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium40/index.m3u8|referer=https://widevine.licenses4.me/


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tsn1.ca" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/TSN1.svg/640px-TSN1.svg.png",TSN 1
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium111/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tsn2.ca" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/TSN2.svg/640px-TSN2.svg.png",TSN 2
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium112/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tsn3.ca" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/TSN3.svg/640px-TSN3.svg.png",TSN 3
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium113/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tsn4.ca" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/TSN4.svg/640px-TSN4.svg.png",TSN 4
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium114/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="tsn5.ca" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/TSN5.svg/640px-TSN5.svg.png",TSN 5
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium115/index.m3u8|referer=https://widevine.licenses4.me/
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sportstv1" tvg-logo="https://rentapi.blackboxsys.net/images/png/pt-sporttv1.png",Sports TV1
https://live-streaming-3.vip-streaming.com/cloudstreaming/SPORT%20TV%201%20Portugal/playlist.m3u8|Referer=https://api-soccer.iamtheme.com

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sportstv2" tvg-logo="https://rentapi.blackboxsys.net/images/png/pt-sporttv2.png",Sports TV2
https://live-streaming-3.vip-streaming.com/cloudstreaming/SPORT%20TV%202%20Portugal/playlist.m3u8?|Referer=https://api-soccer.iamtheme.com

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sportstv3" tvg-logo="https://rentapi.blackboxsys.net/images/png/pt-sporttv3.png",Sports TV3
https://rr3-ic3d-ndjcs.huaweicdncloud.com/dooball2you/sporttv3/playlist.m3u8?|Referer=https://www.dooballfree24hr.com/


#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="sportstv4" tvg-logo="https://rentapi.blackboxsys.net/images/png/pt-sporttv4.png",Sports TV4
https://rr3-ic3d-ndjcs.huaweicdncloud.com/dooball2you/sporttv4/playlist.m3u8?|Referer=https://www.dooballfree24hr.com/
#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="vsportextra.se" tvg-logo="https://rentapi.blackboxsys.net/images/png/pt-sporttv5.png", Sports TV5
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0
https://live-streaming-3.vip-streaming.com/cloudstreaming/SPORT%20TV%205%20Portugal/playlist.m3u8|Referer=https://api-soccer.iamtheme.com

#EXTINF:-1 group-title="กีฬาต่างประเทศ" tvg-id="wwenetwork.us" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/WWE_Logo.svg/526px-WWE_Logo.svg.png",WWE HD
#EXTVLCOPT:http-referrer=https://livehdplay.ru/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webudit.hlsjs.ru/lb/premium376/index.m3u8
http://playtv.my.id/play/PremierHD1.m3u8
https://us.score911.cc/us_wwe/index.m3u8|Referer=https://aesport.tv/
https://ctrl.laotv.la/live/WWE/index.m3u8


#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/tntsport1.png" group-title="SPORTS 24H.tv",TNT SPORT 1
https://nl.score911.cc/uk_bts1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/tntsport2.png" group-title="SPORTS 24H.tv",TNT SPORT 2
https://nl.score911.cc/uk_bts2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/tntsport3.png" group-title="SPORTS 24H.tv",TNT SPORT 3
https://nl.score911.cc/uk_bts3/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/26.png" group-title="SPORTS 24H.tv",PREMIER SPORTS 1
https://nl.score911.cc/uk_premiersports1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/27.png" group-title="SPORTS 24H.tv",PREMIER SPORTS 2
https://nl.score911.cc/uk_premiersports2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://telegra.ph/file/25f820ae7e7e4bde6b88c.png" group-title="SPORTS 24H.tv",BBC One
https://nl2.score911.cc/uk_bbc1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/99.png" group-title="SPORTS 24H.tv",BBC Two
https://nl2.score911.cc/uk_bbc2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/101.png" group-title="SPORTS 24H.tv",BBC Three
https://nl2.score911.cc/uk_bbc3/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/102.png" group-title="SPORTS 24H.tv",Channel 4
https://nl2.score911.cc/uk_channel4/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/103.png" group-title="SPORTS 24H.tv",Channel 5
https://nl2.score911.cc/uk_channel5/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/57.png" group-title="SPORTS 24H.tv",Sky Sports Football
https://nl.score911.cc/uk_ssfb/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/104.png" group-title="SPORTS 24H.tv",ITV 1
https://nl2.score911.cc/uk_itv1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/58.png" group-title="SPORTS 24H.tv",Sky Sports Premier League
https://nl.score911.cc/uk_ssepl/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/105.png" group-title="SPORTS 24H.tv",ITV 2
https://nl2.score911.cc/uk_itv2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/106.png" group-title="SPORTS 24H.tv",MTV
https://nl2.score911.cc/uk_mtv/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/28.png" group-title="SPORTS 24H.tv",Sky Sports F1
https://nl.score911.cc/uk_ssf1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/29.png" group-title="SPORTS 24H.tv",Sky Sports Criket
https://nl.score911.cc/uk_sscrick/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/113.png" group-title="SPORTS 24H.tv",Super Sport Tennis
https://us.score911.cc/za_sstennis/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/114.png" group-title="SPORTS 24H.tv",Sky Sports Golf
https://nl.score911.cc/uk_ssgolf/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/115.png" group-title="SPORTS 24H.tv",Sky Sports News
https://nl.score911.cc/uk_ssnews/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/67.png" group-title="SPORTS 24H.tv",BBC World News
https://nl2.score911.cc/uk_bbcnews/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/zassrugby.png" group-title="SPORTS 24H.tv",Super Sport Rugby
https://us.score911.cc/za_ssrugby/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/88.png" group-title="SPORTS 24H.tv",USA Network
https://us.score911.cc/us_usa/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/70.png" group-title="SPORTS 24H.tv",CBS Sports Network
https://us.score911.cc/us_cbssportsnetwork/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/117.png" group-title="SPORTS 24H.tv",WWE Network
https://us.score911.cc/us_wwe/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/nfl-network.png" group-title="SPORTS 24H.tv",NFL RedZone
https://us.score911.cc/us_nflrz/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/40.png" group-title="SPORTS 24H.tv",BEIN SPORTS 1
https://nl.score911.cc/fr_beinsports1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/41.png" group-title="SPORTS 24H.tv",BEIN SPORTS 2
https://nl.score911.cc/fr_beinsports2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/13.png" group-title="SPORTS 24H.tv",RMC SPORT 1
https://nl.score911.cc/fr_rmcsport1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/upload/Livetv/RMC_SPORT_2.png" group-title="SPORTS 24H.tv",RMC SPORT 2
https://nl.score911.cc/fr_rmcsport2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/33.png" group-title="SPORTS 24H.tv",Eleven Sport 1
https://nl.score911.cc/pt_elevensport1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/32.png" group-title="SPORTS 24H.tv",Eleven Sport 2
https://nl.score911.cc/pt_elevensport2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/31.png" group-title="SPORTS 24H.tv",Eleven Sport 3
https://nl.score911.cc/pt_elevensport3/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/36.png" group-title="SPORTS 24H.tv",Sport  TV 1
https://nl.score911.cc/pt_sporttv1/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/37.png" group-title="SPORTS 24H.tv",Sport  TV 2
https://nl.score911.cc/pt_sporttv2/index.m3u8|Referer=https://24hsport.tv/
#EXTINF:-1 group-logo="https://image.24hsport.tv/tvs/38.png" group-title="SPORTS 24H.tv",Sport  TV 3
https://nl.score911.cc/pt_sporttv3/index.m3u8|Referer=https://24hsport.tv/

                            ###### Foreign TV#####
                           ####VISIONPLUS####

#EXTM3U
#EXTINF:-1 tvg-id="KIX - [Channel 161].id" tvg-name="KIX" tvg-logo="https://gdplayertv.top/assets/img/logo/kix.png" group-title="VISIONPLUS", KIX
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/KIX/sa_dash_vmx/KIX.mpd
#EXTINF:-1 tvg-id="Lifetime - [Channel 167].id" tvg-name="LIFETIME" tvg-logo="https://gdplayertv.top/assets/img/logo/lifetime-tv.png" group-title="VISIONPLUS", LIFETIME
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Lifetime/sa_dash_vmx/Lifetime.mpd
#EXTINF:-1 tvg-id="tvN - [Channel 158].id" tvg-name="TVN" tvg-logo="https://gdplayertv.top/assets/img/logo/tvn.png" group-title="VISIONPLUS", TVN
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/tvN/sa_dash_vmx/tvN.mpd
#EXTINF:-1 tvg-id="Vision Prime HD - [Channel 1].id" tvg-name="VISION PRIME" tvg-logo="https://gdplayertv.top/assets/img/logo/vision-prime.png" group-title="VISIONPLUS", VISION PRIME
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/VisionPrime/sa_dash_vmx/VisionPrime.mpd
#EXTINF:-1 tvg-id="OK TV - [Channel 95].id" tvg-name="OK TV" tvg-logo="https://gdplayertv.top/assets/img/logo/ok-tv.png" group-title="VISIONPLUS", OK TV
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/OKTV/sa_dash_vmx/OKTV.mpd

#EXTINF:-1 tvg-id="AXN - [Channel 154].id" tvg-name="AXN" tvg-logo="https://gdplayertv.top/assets/img/logo/axn-asia.png" group-title="VISIONPLUS", AXN
#EXTVLCOPT:http-referrer=https://www.visionplus.id/ 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/AXN/sa_dash_vmx/AXN.mpd

#EXTINF:-1 tvg-id="CCM - [Channel 22].id" tvg-name="CCM" tvg-logo="https://gdplayertv.top/assets/img/logo/ccm.png" group-title="VISIONPLUS", CCM
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/CelestialClassic/sa_dash_vmx/CelestialClassic.mpd

#EXTINF:-1 tvg-id="Celestial VISION - [Channel 20].id" tvg-name="CELESTIAL VISION" tvg-logo="https://gdplayertv.top/assets/img/logo/ccm.png" group-title="VISIONPLUS", CELESTIAL VISION
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/CelestialMovie/sa_dash_vmx/CelestialMovie.mpd

#EXTINF:-1 tvg-id="CINEMACHI HD - [Channel 401].id" tvg-name="CINEMACHI" tvg-logo="https://gdplayertv.top/assets/img/logo/cinemachi.png" group-title="VISIONPLUS", CINEMACHI 
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cinemachi-HD/sa_dash_vmx/Cinemachi-HD.mpd

#EXTINF:-1 tvg-id="CINEMACHI ACTION - [Channel 8].id" tvg-name="CINEMACHI ACTION" tvg-logo="https://i.ibb.co/S0R9RGP/CINEMACHIACT.png" group-title="VISIONPLUS", CINEMACHI ACTION
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cinemachi-Action/sa_dash_vmx/Cinemachi-Action.mpd

#EXTINF:-1 tvg-id="CINEMACHI MAX HD - [Channel 404].id" tvg-name="CINEMACHI MAX" tvg-logo="https://gdplayertv.top/assets/img/logo/cinemachi-action.png" group-title="VISIONPLUS", CINEMACHI MAX
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cinemachi-Max-HD/sa_dash_vmx/Cinemachi-Max-HD.mpd

#EXTINF:-1 tvg-id="CINEMACHI XTRA HD - [Channel 405].id" tvg-name="CINEMACHI XTRA" tvg-logo="https://gdplayertv.top/assets/img/logo/cinemachi-xtra.png" group-title="VISIONPLUS", CINEMACHI XTRA
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cinemachi-Xtra-HD/sa_dash_vmx/Cinemachi-Xtra-HD.mpd

#EXTINF:-1 tvg-id="CinemaWorld.my" tvg-name="CINEMA WORLD" tvg-logo="https://gdplayertv.top/assets/img/logo/cinema-world.png" group-title="VISIONPLUS", CINEMA WORLD
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/CinemaWorld/sa_dash_vmx/CinemaWorld.mpd

#EXTINF:-1 tvg-id="" tvg-name="FREEMOVIE PLUS" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1CUeklEqQIUsl7mM-zSR0f2dlvO9ZoBsqPQ&usqp=CAU" group-title="VISIONPLUS" , FREEMOVIE PLUS
https://ottstudio-freeVISIONplus-1-us.tcl.wurl.tv/playlist.m3u8

#EXTINF:-1 tvg-id="Galaxy - [Channel 13].id" tvg-name="Galaxy" tvg-logo="https://gdplayertv.top/assets/img/logo/galaxy.png" group-title="VISIONPLUS", GALAXY
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Galaxy-HD/sa_dash_vmx/Galaxy-HD.mpd

#EXTINF:-1 tvg-id="Galaxy Premium - [Channel 12].id" tvg-name="Galaxy Premium" tvg-logo="https://gdplayertv.top/assets/img/logo/galaxy-premium.png" group-title="VISIONPLUS", GALAXY PREMIUM
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/GalaxyPremium-HD/sa_dash_vmx/GalaxyPremium-HD.mpd

#EXTINF:-1 tvg-id="BBC Earth HD - [Channel 461].id" tvg-name="BBC EARTH" tvg-logo="https://gdplayertv.top/assets/img/logo/bbc-earth.png" group-title="VISIONPLUS", BBC EARTH
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/BBCEarth-HD/sa_dash_vmx/BBCEarth-HD.mpd

#EXTINF:-1 tvg-id="Crime Investigation - [Channel 207].id" tvg-name="CRIME INVESTIGATION" tvg-logo="https://gdplayertv.top/assets/img/logo/ci.png" group-title="VISIONPLUS", CRIME INVESTIGATION
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/CrimeInvestigation/sa_dash_vmx/CrimeInvestigation.mpd

#EXTINF:-1 tvg-id="Discovery Channel" tvg-name="DISCOVERY" tvg-logo="https://gdplayertv.top/assets/img/logo/discovery-channel.png" group-title="VISIONPLUS", DISCOVERY
http://vod.linknetott.swiftcontent.com/Content/HLS/Live/Channel(ch29)/index.m3u8


#EXTINF:-1 tvg-id="Global Trekker - [Channel 201].id" tvg-name="GLOBAL TREKKER" tvg-logo="https://gdplayertv.top/assets/img/logo/global-trekker.png" group-title="VISIONPLUS", GLOBAL TREKKER
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Globaltrekker/sa_dash_vmx/Globaltrekker.mpd

#EXTINF:-1 tvg-id="History - [Channel 206].id" tvg-name="HISTORY" tvg-logo="https://gdplayertv.top/assets/img/logo/history-tv.png" group-title="VISIONPLUS", HISTORY
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/History/sa_dash_vmx/History.mpd

#EXTINF:-1 tvg-id="National Geographic Channel HD - [Channel 460].id" tvg-name="" tvg-logo="https://gdplayertv.top/assets/img/logo/nat-geo.png" group-title="VISIONPLUS", NATIONAL GEOGRAPHIC
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/NatGeoChannel/sa_dash_vmx/NatGeoChannel.mpd

#EXTINF:-1 tvg-id="Nat Geo Wild" tvg-name="NATIONAL GEOGRAPHIC WILD" tvg-logo="https://gdplayertv.top/assets/img/logo/nat-geo-wild.png" group-title="VISIONPLUS", NATIONAL GEOGRAPHIC WILD
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/NatGeoWild/sa_dash_vmx/NatGeoWild.mpd

#EXTINF:-1 tvg-id="Outdoor Channel" tvg-name="OUTDOOR CHANNEL" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7-VWGlay-RmUEBvaaVfUSQhvjJJZXNwnKzA&usqp=CAU" group-title="VISIONPLUS", OUTDOOR CHANNEL
**https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg00718-outdoorchannela-outdoorchannel-lgau/playlist.m3u8
https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg00718-outdoorchannela-outdoortvnz-samsungnz/playlist.m3u8

#EXTINF:-1 tvg-id="Animax - [Channel 157].id" tvg-name="" tvg-logo="https://gdplayertv.top/assets/img/logo/animax.png" group-title="VISIONPLUS", ANIMAX
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Animax/sa_dash_vmx/Animax.mpd

#EXTINF:-1 tvg-id="BabyTV - [Channel 40].id" tvg-name="" tvg-logo="https://upload.wikimedia.org/wikipedia/en/4/45/BabyTV.png" group-title="VISIONPLUS", BABY TV
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/BabyTV-NewHD/sa_dash_vmx/BabyTV-NewHD.mpd

#EXTINF:-1 tvg-id="CBeebies - [Channel 41].id" tvg-name="CBeebies" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMw4O_BLUcKAgj7Hvrq75P0PCV0JX7sN8nuA&usqp=CAU" group-title="VISIONPLUS", CBEEBIES
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cbeebies/sa_dash_vmx/Cbeebies.mpd

#EXTINF:-1 tvg-id="CINEMACHI VISION HD - [Channel 403].id" tvg-name="CINEMACHI VISION" tvg-logo="https://www.mncvision.id/userfiles/image/channel/channel_7.png" group-title="VISIONPLUS", CINEMACHI VISION
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Cinemachi-VISION-HD/sa_dash_vmx/Cinemachi-VISION-HD.mpd  

#EXTINF:-1 tvg-id="Dreamworks - [Channel 47].id" tvg-name="" tvg-logo="https://gdplayertv.top/assets/img/logo/dreamworks.png" group-title="VISIONPLUS", DREAMWORKS
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Dreamwork-HD/sa_dash_vmx/Dreamwork-HD.mpd
a,
#EXTINF:-1 tvg-id="Nickelodeon - [Channel 49].id" tvg-name="" tvg-logo="https://gdplayertv.top/assets/img/logo/nickelodeon.png" group-title="VISIONPLUS", NICKELODEON
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/Nickelodeon/sa_dash_vmx/Nickelodeon.mpd

#EXTINF:-1 tvg-id="Nick Jr. HD - [Channel 472].id" tvg-name="" tvg-logo="https://gdplayertv.top/assets/img/logo/nick-junior.png" group-title="VISIONPLUS", NICK JR
#EXTVLCOPT:http-referrer=https://www.visionplus.id/
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NDIzMDJhZmUtYWRjMi0zNGJkLTkyN2EtYmE1ZDFlZWIwODEz
https://nyanv-live-cdn.mncnow.id/live/eds/NickJr-HDD/sa_dash_vmx/NickJr-HDD.mpd


#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230803/video/fcc4c738-1a79-44e2-a909-9d9ce3348b82.png", Workpoint
https://ctrl.laotv.la/live/WorkPoint/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230323/video/d7c937f5-1f07-495c-9d69-eb974a91a83e.jpeg", OneHD
https://ctrl.laotv.la/live/OneHD/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230803/video/fbcc05df-ab6f-4559-b932-248dccf9c85c.png", GMM25
https://ctrl.laotv.la/live/GMM25/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/e797c4ed-4c76-4b8d-a881-09b27905edad.jpg", CH3 HD
https://ctrl.laotv.la/live/3HD/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/e1f5b7e5-16c1-4936-9f52-0b948c18900c.png", CH5
https://ctrl.laotv.la/live/Thai5/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230519/video/04085ab0-a6af-4e89-b395-6e7e0cf6b470.png", AMARIN TV HD
https://ctrl.laotv.la/live/AMARINTVHD/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/7f72bd64-70c8-4d5a-ae7b-f78945688188.png", THAIRATH TV HD
https://ctrl.laotv.la/live/THAIRATHTVHD/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230618/video/d6b5780f-d6bb-4da9-a64c-de6d78124a9e.png", NationTV
https://ctrl.laotv.la/live/NationTV/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230618/video/806eb55e-d8ce-46c9-904d-7701caaeafcc.png", NBT
https://ctrl.laotv.la/live/NBT/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230420/video/9f94a26f-4a56-407e-98e1-e54ccd4deec2.jpg", MONO29
https://ctrl.laotv.la/live/Mono29/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/57f8c7b4-bd8d-4ad0-954f-5445833b849a.png", Thai PBS
https://ctrl.laotv.la/live/ThaiPBS/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/3bbe12fc-c38e-4746-9deb-30392fb3d5ef.png", True4U
https://ctrl.laotv.la/live/True4U/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/ca80bc1c-d564-4b85-b2f6-5c8327ae10ab.png", CH8
https://ctrl.laotv.la/live/CH8/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/68ba60f7-92e6-4fa3-a6cb-16e1b6e683c0.png", MCOT9
https://ctrl.laotv.la/live/Mcot/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/6c7058d3-35f7-4e2c-85ef-b1f6ba3949f6.png", T Sports 7
https://ctrl.laotv.la/live/TSports7/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230618/video/83aae5ac-bb3a-49e6-a2d1-3e88d75e066d.png", TNN2
https://ctrl.laotv.la/live/TNN2/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230618/video/821f2809-ffdb-42ff-b6eb-4331754341d7.png", TNN24
https://ctrl.laotv.la/live/TNN24/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230802/video/e0e25d1f-2a79-46ad-8817-7ad690948fd1.png", JKN18
https://ctrl.laotv.la/live/JKN18/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/44bda67e-5e21-479e-aa78-1956ba229382.jpg", CH7 HD
https://ctrl.laotv.la/live/Thai7/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/20b89491-9c17-4a31-a050-193a8ba939bd.png", PPTV HD
https://ctrl.laotv.la/live/PPTVHD/index.m3u8


#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230728/video/e364dd59-562b-4157-a44a-c11c3b728557.jpeg", Bein Sports 1
https://ctrl.laotv.la/live/Bsport1/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230728/video/394df566-c126-426a-854a-c41b75025213.jpeg", Bein Sports 2
https://ctrl.laotv.la/live/Bsport2/index.m3u8

#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://fn.dmpcdn.com/TrueIDWeb/Home/Campaigns/Channel-True-Premier-Football-HD1.png", True Premier Football 1
https://ctrl.laotv.la/live/TSport1/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://fn.dmpcdn.com/TrueIDWeb/Home/Campaigns/Channel-True-Premier-Football-HD2.png", True Premier Football 2
https://ctrl.laotv.la/live/TSport2/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://fn.dmpcdn.com/TrueIDWeb/Home/Campaigns/Channel-True-Premier-Football-HD3.png", True Premier Football 3
https://ctrl.laotv.la/live/TrueSport2/index.m3u8

#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://cms.dmpcdn.com/livetv/2019/10/28/feddd690-f972-11e9-91cd-2f79be09d2b3_original.png", True Sports 1
https://ctrl.laotv.la/live/TrueSport6/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://cms.dmpcdn.com/livetv/2022/01/12/28a5ae30-7374-11ec-91d2-797a50c5a656_webp_320.png", True Sports 3
https://ctrl.laotv.la/live/TrueSport3/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://cms.dmpcdn.com/livetv/2019/10/28/e52c8980-f972-11e9-a1fc-5dda12c8d080_320.png", True Sports 7
https://edge1.laotv.la/live/THD7/index.m3u8


#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/47acb94e-a2a5-4fde-bd9f-a0ec148cdf86.png", LNTV3
https://ctrl.laotv.la/live/LNTV3/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/57c9c7ba-bcc7-4c30-8ad4-d4fab611a2b7.png", LNTV1
https://ctrl.laotv.la/live/LNTV1/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/4f032dfc-bfd4-4c69-982b-361b9a4795a4.png", LaoStar
https://ctrl.laotv.la/live/LaoStar/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/42c67d3b-86e3-4e71-8f05-6677d1d31d3f.png", VTE9
https://ctrl.laotv.la/live/VTE9/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230804/video/d632d48f-2850-44ff-9fd6-e859e6edbed3.png", LATV
https://ctrl.laotv.la/live/LATV/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230609/video/fc251bad-66db-4d92-bbb4-d1aab661f56e.png", PSTV
https://ctrl.laotv.la/live/PSTV/index.m3u8
#EXTINF:-1 group-title="🇱🇦| ลาวทีวี" tvg-logo="https://poc-cdn-google.sdmc.tv/xmediatv/public/upload/100036087499/20230802/video/23dd1aba-312f-41fe-ab8d-6b928455af0a.png", Lao ESTV
https://ctrl.laotv.la/live/LaoESTV/index.m3u8



#EXTM3U 
#EXTINF:-1 tvg-id="TV1.My" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUDzI5hF_Ozo8eGzaKLK-yo2Rj_wQ2zCqB1Q&usqp=CAU" group-title="MALAYSIA",TV1
https://d25tgymtnqzu8s.cloudfront.net/smil:tv1/manifest.mpd
https://d25tgymtnqzu8s.cloudfront.net/smil:tv1/playlist.m3u8?id=1|Referer=https://rtm-player.glueapi.io/
#EXTINF:-1 tvg-id="TV2.My" tvg-logo="https://i.ytimg.com/vi/sxTDt5c4tCg/mqdefault.jpg" group-title="MALAYSIA",TV2
https://d25tgymtnqzu8s.cloudfront.net/smil:tv2/manifest.mpd

#EXTINF:-1 tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/106_144.png" group-title="MALAYSIA", TV3
http://198.16.100.90:8278/TV3/playlist.m3u8?tid=MBAB6337539663375396&ct=19249&tsum=d654aed09f7731acae9bc6b5fafeec6d
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=3afe30ee4ea24a67fe5a2ef06e83db0b:27a2f71d87bf5eb105af096fb6605d97
https://aqfadtv.xyz/live/tv3/index.mpd

#EXTINF:-1 group-title="MALAYSIA" ch-number="103" tvg-id="103" tvg-chno="103" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/106_144.png",TV3
#KODIPROP:inputstream.adaptive.license_type=clearkey 
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/tv3/ 
https://aqfadtv.xyz/live/tv3/index.mpd

#EXTINF:-1 tvg-id="TV6.My" tvg-logo="https://cdn.ksa.my.id/tv6.png" group-title="MALAYSIA",TV6
https://d25tgymtnqzu8s.cloudfront.net/smil:tv6/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/8tv/
#EXTINF:-1 tvg-id="8TV.My" tvg-logo="https://alchetron.com/cdn/8tv-MALAYSIA-00c80dd7-0785-409b-be41-fdc503aae1b-resize-750.jpg" group-title="MALAYSIA", 8TV (Unifi)
https://aqfadtv.xyz/live/tv9/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/tv9/
#EXTINF:-1 tvg-id="TV9.My" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGv3vegjeW4CUGpE-JAWz00FGVowDoA1TJrw&usqp=CAU" group-title="MALAYSIA", TV9 (Unifi)
https://aqfadtv.xyz/live/tv9/index.mpd

#EXTINF:-1 tvg-id="Okey.My" tvg-logo="https://cdn.ksa.my.id/rtmokey.png" group-title="MALAYSIA",Okey
https://d25tgymtnqzu8s.cloudfront.net/smil:okey/manifest.mpd
https://d25tgymtnqzu8s.cloudfront.net/smil:okey/chunklist_b4596000_slENG.m3u8?id=5|Referer=https://rtm-player.glueapi.io/

#EXTINF:-1 tvg-id="BertiaRTM.My" tvg-logo="https://cdn.ksa.my.id/bes.png" group-title="MALAYSIA",Berita RTM
https://d25tgymtnqzu8s.cloudfront.net/smil:berita/chunklist_b4596000_slENG.m3u8?id=5|Referer=https://rtm-player.glueapi.io/

#EXTINF:-1 tvg-id="SukanRTM.My" tvg-logo="https://cdn.ksa.my.id/sukanrtm.png" group-title="MALAYSIA",Sukan RTM
https://d25tgymtnqzu8s.cloudfront.net/smil:sukan/manifest.mpd

#EXTINF:-1 tvg-id="" tvg-logo="https://cdn.ksa.my.id/dramasangat.png" group-title="MALAYSIA", Drama Sangat
https://live-sg1.global.ssl.fastly.net/live-hls/tonton5_720p/index.m3u8
#EXTINF:-1 tvg-id="NTV7.My" tvg-logo="https://cdn.ksa.my.id/didiktvkpm.png" group-title="MALAYSIA", NTV7 (DidikTV KPM)
https://live-sg1.global.ssl.fastly.net/live-hls/tonton2_720p/index.m3u8

#EXTINF:-1 tvg-id="" tvg-name="MY: 8TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-11/e17423b3478a962cdb92c6c20a15f178.jpg" group-title="MALAYSIA",MY: 8TV
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/171968.ts
#EXTINF:-1 tvg-id="" tvg-name="MY: Animax" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/e0ca9c22b972add893fdad34af4255bc.png" group-title="MALAYSIA",MY: Animax
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/157486.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Arena" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/f9cbb250de1822306dc0b7e9cdd23c9a.png" group-title="MALAYSIA",MY: Astro Arena
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/157485.ts
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Awani" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/e976949486bc089b9dec986e9a860ff8.png" group-title="MALAYSIA",MY: Astro Awani
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/157478.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Cricket" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/edc8a9c38c820781eb4785f4e5ee89ca.png" group-title="MALAYSIA",MY: Astro Cricket
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/157565.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Oasis" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/28fc1cfc2e9b5b2ba64f6bf5bcaa357d.png" group-title="MALAYSIA",MY: Astro Oasis
http://198.16.100.90:8278/Oasis/playlist.m3u8?tid=MABA2020629120206291&ct=19249&tsum=46be05252007b1efaae28ae3ab4cc7bb
http://iptvmedia.live:8080/streamnet/a8b92bb196/157489
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Prima" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/584608e7b0eb904734396e6cc6831811.png" group-title="MALAYSIA",MY: Astro Prima
http://198.16.100.90:8278/Prima/playlist.m3u8?tid=MDCD7525162675251626&ct=19249&tsum=baa42cb947105579e476ec0c5b71043d
#http://iptvmedia.live:8080/streamnet/a8b92bb196/157467
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro SuperSport" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/56d8756215a55bb4bc650428934f45d4.png" group-title="MALAYSIA",MY: Astro SuperSport
http://iptvmedia.live:8080/live/streamnet/a8b92bb196/146068.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro SuperSport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/601d9900ec857fb5c10762208e18f474.png" group-title="MALAYSIA",MY: Astro SuperSport 2
http://iptvmedia.live:8080/streamnet/a8b92bb196/157556
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro SuperSport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/c450e8241eb19fdbc99b78c96be08c2d.png" group-title="MALAYSIA",MY: Astro SuperSport 3
http://iptvmedia.live:8080/streamnet/a8b92bb196/157557
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro SuperSport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/a24abde2dc683d551ebfae1f0820315c.png" group-title="MALAYSIA",MY: Astro SuperSport 4
http://iptvmedia.live:8080/streamnet/a8b92bb196/157558
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro SuperSport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-02/480daf2471d76a0819242a59da7005f9.png" group-title="MALAYSIA",MY: Astro SuperSport 5
http://iptvmedia.live:8080/streamnet/a8b92bb196/287792
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Vaanavil" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/bb06ccbe93af0e4d72aad4c77c5cb4c6.png" group-title="MALAYSIA",MY: Astro Vaanavil
http://iptvmedia.live:8080/streamnet/a8b92bb196/201163
#EXTINF:-1 tvg-id="" tvg-name="MY: Astro Xiao Tai Yang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/fa7dae21ca0a660204573e4d010232ab.png" group-title="MALAYSIA",MY: Astro Xiao Tai Yang
http://iptvmedia.live:8080/streamnet/a8b92bb196/201164
#EXTINF:-1 tvg-id="" tvg-name="MY: AXN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/2d7d739d57aa860159c36df8c746c779.png" group-title="MALAYSIA",MY: AXN
http://iptvmedia.live:8080/streamnet/a8b92bb196/157542
#EXTINF:-1 tvg-id="" tvg-name="MY: BBC Earth" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/c23b25dd57cbcc578a72dda7e35fdf08.png" group-title="MALAYSIA",MY: BBC Earth
http://iptvmedia.live:8080/streamnet/a8b92bb196/171979
#EXTINF:-1 tvg-id="" tvg-name="MY: beIN Sports" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/661d6fd8993dd9aaf43e249d036e9eb3.jpg" group-title="MALAYSIA",MY: beIN Sports
http://iptvmedia.live:8080/streamnet/a8b92bb196/157561
#EXTINF:-1 tvg-id="" tvg-name="MY: Bloomberg TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/602e805f1abfd464565db600ffd3f028.png" group-title="MALAYSIA",MY: Bloomberg TV
http://iptvmedia.live:8080/streamnet/a8b92bb196/157533
#EXTINF:-1 tvg-id="" tvg-name="MY: Boomerang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/515d63ff66edb49dc64a03093e9f6fd2.png" group-title="MALAYSIA",MY: Boomerang
http://iptvmedia.live:8080/streamnet/a8b92bb196/171955
#EXTINF:-1 tvg-id="" tvg-name="MY: Cartoonito" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="MALAYSIA",MY: Cartoonito
http://iptvmedia.live:8080/streamnet/a8b92bb196/300865
#EXTINF:-1 tvg-id="" tvg-name="MY: Celestial Classic Movies (CCM)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/feda2de53c7fd947f29ff4740860c233.png" group-title="MALAYSIA",MY: Celestial Classic Movies (CCM)
http://iptvmedia.live:8080/streamnet/a8b92bb196/157512
#EXTINF:-1 tvg-id="" tvg-name="MY: Celestial Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/51e29412b2a80c8afa779e56b99dccdd.png" group-title="MALAYSIA",MY: Celestial Movies
http://iptvmedia.live:8080/streamnet/a8b92bb196/174687
#EXTINF:-1 tvg-id="" tvg-name="MY: Crime+ Investigation" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/ad7a1e1bb94a07f128ce21def6a0adc3.png" group-title="MALAYSIA",MY: Crime+ Investigation
http://iptvmedia.live:8080/streamnet/a8b92bb196/157554
#EXTINF:-1 tvg-id="" tvg-name="MY: Discovery Science" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/838a78d02f3d18a23b94402dd8420a2b.png" group-title="MALAYSIA",MY: Discovery Science
http://iptvmedia.live:8080/streamnet/a8b92bb196/157530
#EXTINF:-1 tvg-id="" tvg-name="MY: Dreamworks" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="MALAYSIA",MY: Dreamworks
http://iptvmedia.live:8080/streamnet/a8b92bb196/171959
#EXTINF:-1 tvg-id="" tvg-name="MY: FOX SPORTS 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/32a4269c4918eeef41af63deb0f43083.png" group-title="MALAYSIA",MY: FOX SPORTS 2
http://iptvmedia.live:8080/streamnet/a8b92bb196/157488
#EXTINF:-1 tvg-id="" tvg-name="MY: GO SHOP" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/2e10818ae32a06e6561f9dd7d5f6b12d.png" group-title="MALAYSIA",MY: GO SHOP
http://iptvmedia.live:8080/streamnet/a8b92bb196/264511
#EXTINF:-1 tvg-id="" tvg-name="MY: Harvest TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="MALAYSIA",MY: Harvest TV
http://iptvmedia.live:8080/streamnet/a8b92bb196/299917
#EXTINF:-1 tvg-id="" tvg-name="MY: Hits" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/25ab65a39a10d628b5c9319b423b6497.png" group-title="MALAYSIA",MY: Hits
http://iptvmedia.live:8080/streamnet/a8b92bb196/157545
#EXTINF:-1 tvg-id="" tvg-name="MY: HITS Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/652a9e2547c9b24a6a2b0eb16b43a1f1.png" group-title="MALAYSIA",MY: HITS Movies
http://iptvmedia.live:8080/streamnet/a8b92bb196/157477
#EXTINF:-1 tvg-id="" tvg-name="MY: KIX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="MALAYSIA",MY: KIX
http://iptvmedia.live:8080/streamnet/a8b92bb196/299963
#EXTINF:-1 tvg-id="" tvg-name="MY: Local Now Family Flix" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-10/98ac421179bbfd4dc8f4f4640667e35b.png" group-title="MALAYSIA",MY: Local Now Family Flix
http://iptvmedia.live:8080/streamnet/a8b92bb196/296889
#EXTINF:-1 tvg-id="" tvg-name="MY: MTV" tvg-logo="http://s3.i3ns.net/portal/picon/2020-12/02fe87f4680ce4c67197ba3c4c5bf9c7.png" group-title="MALAYSIA",MY: MTV
http://iptvmedia.live:8080/streamnet/a8b92bb196/157555
#EXTINF:-1 tvg-id="" tvg-name="MY: Nick Jr" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/92307ca79c909c2f7881199792c74c0b.png" group-title="MALAYSIA",MY: Nick Jr
http://iptvmedia.live:8080/streamnet/a8b92bb196/157546
#EXTINF:-1 tvg-id="" tvg-name="MY: NTV 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/b92ffe0e329e6808620cf9b9f92f1523.png" group-title="MALAYSIA",MY: NTV 7
http://iptvmedia.live:8080/streamnet/a8b92bb196/174695
#EXTINF:-1 tvg-id="" tvg-name="MY: RTB Sukmaindera" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/667e24a26ecfe1070bd6a40a113c0159.png" group-title="MALAYSIA",MY: RTB Sukmaindera
http://iptvmedia.live:8080/streamnet/a8b92bb196/299546
#EXTINF:-1 tvg-id="" tvg-name="MY: RTM TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/7f3190f95ee41181d69a2edcc5321131.png" group-title="MALAYSIA",MY: RTM TV 1
http://iptvmedia.live:8080/streamnet/a8b92bb196/158357
#EXTINF:-1 tvg-id="" tvg-name="MY: RTM TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/4d495580f894286e82e1f9ee33d2874b.png" group-title="MALAYSIA",MY: RTM TV 2
http://iptvmedia.live:8080/streamnet/a8b92bb196/158355
#EXTINF:-1 tvg-id="" tvg-name="MY: TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-11/338111c497a80baf3e1dccfe7e9a5cc0.jpg" group-title="MALAYSIA",MY: TV 1
http://iptvmedia.live:8080/streamnet/a8b92bb196/300872
#EXTINF:-1 tvg-id="" tvg-name="MY: TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-11/15ec53174f6ecee5d3802b391d75c5a6.jpg" group-title="MALAYSIA",MY: TV 2
http://iptvmedia.live:8080/streamnet/a8b92bb196/300873
#EXTINF:-1 tvg-id="" tvg-name="MY: TV 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/7c4b2443678d05d7f2032e5519eec970.png" group-title="MALAYSIA",MY: TV 3
http://iptvmedia.live:8080/streamnet/a8b92bb196/158360
#EXTINF:-1 tvg-id="" tvg-name="MY: TV 9" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/3adc723d4576cb0b512751fe4073c326.png" group-title="MALAYSIA",MY: TV 9
http://iptvmedia.live:8080/streamnet/a8b92bb196/171953
#EXTINF:-1 tvg-id="" tvg-name="MY: TV Alhijrah" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/7bcedbeb3814000d4e785498f51b2099.png" group-title="MALAYSIA",MY: TV Alhijrah
http://iptvmedia.live:8080/streamnet/a8b92bb196/157491
#EXTINF:-1 tvg-id="" tvg-name="MY: TVN Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/66ac88e17edd3d12e424a58a3a9b1d45.png" group-title="MALAYSIA",MY: TVN Movies
http://iptvmedia.live:8080/streamnet/a8b92bb196/297499
#EXTINF:-1 tvg-id="" tvg-name="MY: Warner TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-12/ab95d8e974bb7f697b1dd79c7ac0f765.png" group-title="MALAYSIA",MY: Warner TV
http://iptvmedia.live:8080/streamnet/a8b92bb196/157550

   <meta http-equiv="refresh" content="0;url=https://tv.realmetx.repl.co/error.php">
</head>