<html>
	{"name": "@PLAY-IDTV","author": "ผมเขียนเพลย์ลิสต์ @PlayIDTV","url": "homew3u.php","image": "https://dl.dropbox.com/scl/fi/f8886ysdj8jli4tlvx1sr/20231007_192021.png?rlkey=lb74ax6ar38l2t7mro3wd04do&dl=0","imageScale": "center","groups": [{"name": "PLAYIDTV WIESPLAY","image": "https://dl.dropbox.com/scl/fi/5psd0jcuel4u7uoi6mi14/20231007_191849.jpg?rlkey=zazgtlzcq7xdmup943j33vw4d&dl=0","imageScale": "center","url": "https://2nud.short.gy/playidtv.w3u","import": false},
{"name": "ผู้ดูแลลิงค์","image": "https://www.freepnglogos.com/uploads/communication-internet-line-media-network-online-line-logo-png-13.png","imageScale": "center","url": "https://dl.dropbox.com/s/dzzslbig5wuocpr/info.txt?dl=0","import": false},]},]

<html>
<head>
  <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="ไม่สามารถดูได้">
    <meta name="author" content="https://www.google.co.th/">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="0;url=https://www.google.co.th/">
</head>
<meta http-equiv="refresh" content="0;url=error.php">