<html>
<head>
  <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="ดูไม่ได้พ่อมึงตาย">
พ่อมึงตายทำเองไม่เป็นรึไงวะ
กูทำเพื่อกลุ่มของกู กูไม่ได้ให้มึงขายหรือแจกไปทั่ว
